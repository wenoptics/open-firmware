var classWiFiClient =
[
    [ "WiFiClient", "classWiFiClient.html#aa22ef0fd15a3e2b8ac45eceb0df3bc74", null ],
    [ "WiFiClient", "classWiFiClient.html#a10eaa532a8d95b354fbbe0ed23f071dd", null ],
    [ "available", "classWiFiClient.html#a027090f7f03b80180d23316cf2647cf8", null ],
    [ "connect", "classWiFiClient.html#a9a980afa20a5b18a169837156153a91e", null ],
    [ "connect", "classWiFiClient.html#a8a61c19fc573d90e1f59a3e632706af2", null ],
    [ "connected", "classWiFiClient.html#aaf69c75c27d44c01484185e9306bd8da", null ],
    [ "flush", "classWiFiClient.html#a1cc36e211c82ef9fddf97dda54cacca2", null ],
    [ "operator bool", "classWiFiClient.html#ae531112d39020fc3bdab3b318cccfb2d", null ],
    [ "peek", "classWiFiClient.html#ab47076806232cb80dbabbaa832919d84", null ],
    [ "read", "classWiFiClient.html#a823bdc93651f12103ec4dddb4ee8581d", null ],
    [ "read", "classWiFiClient.html#afca9c595c57ca5b67074422918f52b15", null ],
    [ "status", "classWiFiClient.html#abccde279d6ac21131ef54a4121d14be5", null ],
    [ "stop", "classWiFiClient.html#a43c3ec6dfd681de3eacb1b0ec835991f", null ],
    [ "write", "classWiFiClient.html#a48db220c84756ab99fc6356901ded0f9", null ],
    [ "write", "classWiFiClient.html#aa8b77cac3d176243ddc26903a99ee9f3", null ],
    [ "WiFiServer", "classWiFiClient.html#a98a487eb7fb049868f04e033efbed38f", null ]
];