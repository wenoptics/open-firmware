var WiFiUdp_8h =
[
    [ "WiFiUDP", "classWiFiUDP.html", "classWiFiUDP" ],
    [ "UDP_TX_PACKET_MAX_SIZE", "WiFiUdp_8h.html#a0fdcd947d94b667b5ae13b9dc6966979", null ]
];