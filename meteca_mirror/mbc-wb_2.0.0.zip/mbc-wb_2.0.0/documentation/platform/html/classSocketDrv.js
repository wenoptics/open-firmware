var classSocketDrv =
[
    [ "getClientState", "classSocketDrv.html#ae972dc46876278585ff0073e3d244ce4", null ],
    [ "getData", "classSocketDrv.html#aaa31fa05ea73d9a0aa1acff1ece2d2c9", null ],
    [ "getDataBuf", "classSocketDrv.html#abd15de8d963d29cdd34ff98d3e4d27c0", null ],
    [ "sendData", "classSocketDrv.html#a923c86fde39412fcbfa513aaa0f83c4a", null ],
    [ "sendUdpData", "classSocketDrv.html#ab3a42db96d873ad7b4938954dc8b561d", null ],
    [ "startClient", "classSocketDrv.html#a0bb7fb054bacd4d6df8158f73f68151a", null ],
    [ "startServer", "classSocketDrv.html#a51e3aaebd5a034ec061c1ffb4b561611", null ],
    [ "stopClient", "classSocketDrv.html#a5df150097ea3267c0121e80373bdf854", null ]
];