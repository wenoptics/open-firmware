var classWiFiServer =
[
    [ "WiFiServer", "classWiFiServer.html#a84973ac8552fc2b463394297285550f4", null ],
    [ "available", "classWiFiServer.html#abfd839b75fa3c40bd5e22c4a122ed800", null ],
    [ "begin", "classWiFiServer.html#a953b3d2a3ea0b0582be9535b6aa908d9", null ],
    [ "write", "classWiFiServer.html#aaed8ea03b4c6fc90aa452f816fbbaf1a", null ],
    [ "write", "classWiFiServer.html#a8334bcb9ea8e8035d186d0dc3f1dfb27", null ]
];