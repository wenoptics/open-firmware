var WebPanel_8h =
[
    [ "WebPanelClass", "classWebPanelClass.html", "classWebPanelClass" ],
    [ "Configuration", "classConfiguration.html", "classConfiguration" ],
    [ "CONFIGFILENAME", "WebPanel_8h.html#ae99ca2d2731dcecf9670d172003c467c", null ],
    [ "EMPTY", "WebPanel_8h.html#a2b7cf2a3641be7b89138615764d60ba3", null ],
    [ "JSONEMPTY", "WebPanel_8h.html#a6c1da6a14490606dc2f0390d3cb7a14d", null ],
    [ "MAXVALUESIZE", "WebPanel_8h.html#abfc10fe0dbf6eac8d7da8a18d2b9218a", null ],
    [ "Config", "WebPanel_8h.html#a34430993f800b3bc4571bd4b9a6d9184", null ],
    [ "webPanel", "WebPanel_8h.html#ab65623795e00e23feaa5433a89a13de5", null ]
];