var structtsNetworkParams =
[
    [ "currNetIdx", "structtsNetworkParams.html#a300d6c3ed27b0f75cb5df805829af5d2", null ],
    [ "nScannedNets", "structtsNetworkParams.html#a34c8925d5a4ee0e11ced4dfc2ae7269a", null ]
];