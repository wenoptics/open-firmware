var classConfiguration =
[
    [ "getParam", "classConfiguration.html#abb22a0cd3930e4a56d85145b48a7eabc", null ],
    [ "setParam", "classConfiguration.html#a7d4369d74d925b7d2953fa440aeaf993", null ]
];