var communication_8h =
[
    [ "Communication", "classCommunication.html", "classCommunication" ],
    [ "CUSTOM_CMD_NR", "communication_8h.html#a121ac90239aa17689d2b2d029ab69b52", null ],
    [ "EXT_HANDLES", "communication_8h.html#acc12fdb2e07b3d0f51a2b22e2b18f7c4", null ],
    [ "MIN_CUSTOM_CMD_CODE", "communication_8h.html#af95039556955d96ed902e55c1efd9791", null ],
    [ "ext_callback", "communication_8h.html#a32774489a9f2b5c0f0922b397b0f3760", null ],
    [ "communication", "communication_8h.html#acbef923ad22ef0461dd67c0aaf13c9d7", null ]
];