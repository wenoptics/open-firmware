var structtsSockStatus =
[
    [ "conn", "structtsSockStatus.html#aaabca1f6fb1e74552fd62311a0349bb2", null ],
    [ "inUse", "structtsSockStatus.html#a7e375aca04796b0e1dd152f3fa00e0cd", null ],
    [ "protocol", "structtsSockStatus.html#ae3aa4acc04c59c0bea282b682be9ab8d", null ],
    [ "timeout", "structtsSockStatus.html#abd1b610424fe17f11473df73c6bfcf1f", null ]
];