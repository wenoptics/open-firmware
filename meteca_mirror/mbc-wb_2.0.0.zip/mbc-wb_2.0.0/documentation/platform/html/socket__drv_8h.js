var socket__drv_8h =
[
    [ "SocketDrv", "classSocketDrv.html", "classSocketDrv" ],
    [ "tProtMode", "socket__drv_8h.html#abe8309d290fe4800dda7721d78b3941a", null ],
    [ "eProtMode", "socket__drv_8h.html#af9c9eceddbc082a33e46eedf7f212350", [
      [ "TCP_MODE", "socket__drv_8h.html#af9c9eceddbc082a33e46eedf7f212350a940da991aff186194d5a1048084243e2", null ],
      [ "UDP_MODE", "socket__drv_8h.html#af9c9eceddbc082a33e46eedf7f212350a5386754ac91ae2c07f8b94c952b7b6a2", null ]
    ] ]
];