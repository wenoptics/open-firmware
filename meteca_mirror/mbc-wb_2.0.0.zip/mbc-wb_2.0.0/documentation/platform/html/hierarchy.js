var hierarchy =
[
    [ "Client", null, [
      [ "WiFiClient", "classWiFiClient.html", null ]
    ] ],
    [ "Communication", "classCommunication.html", null ],
    [ "Configuration", "classConfiguration.html", null ],
    [ "Control2WiFi", "classControl2WiFi.html", null ],
    [ "networkParams_s", "structnetworkParams__s.html", null ],
    [ "Server", null, [
      [ "WiFiServer", "classWiFiServer.html", null ]
    ] ],
    [ "SocketDrv", "classSocketDrv.html", null ],
    [ "tsNetworkParams", "structtsNetworkParams.html", null ],
    [ "tsSockStatus", "structtsSockStatus.html", null ],
    [ "UDP", null, [
      [ "WiFiUDP", "classWiFiUDP.html", null ]
    ] ],
    [ "WebPanelClass", "classWebPanelClass.html", null ],
    [ "WiFi2ControlClass", "classWiFi2ControlClass.html", null ],
    [ "WiFiDrv", "classWiFiDrv.html", null ]
];