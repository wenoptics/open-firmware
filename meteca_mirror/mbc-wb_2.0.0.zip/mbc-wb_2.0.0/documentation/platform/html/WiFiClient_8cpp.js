var WiFiClient_8cpp =
[
    [ "ATTEMPTS", "WiFiClient_8cpp.html#a8c730a41dcccce68039aea9f991e1868", null ],
    [ "_internalBuf", "WiFiClient_8cpp.html#ac14ea993850852644315d7baa194429a", null ],
    [ "_internalBufPtr", "WiFiClient_8cpp.html#a5f3e64217233f201f71df6fd4143300b", null ],
    [ "_internalBufSz", "WiFiClient_8cpp.html#a1a375e97361cb662847156b782e16584", null ],
    [ "_sockDataSz", "WiFiClient_8cpp.html#aa9331f58472d6a16d82a10a9d082e997", null ],
    [ "attempts_conn", "WiFiClient_8cpp.html#ac09e0fa1b20f7d9c36bae941cd204ba9", null ],
    [ "client_status", "WiFiClient_8cpp.html#a8e6ec5491cbafe8b06bce4a24901549d", null ]
];