var files_dup =
[
    [ "CommCmd.h", "CommCmd_8h.html", "CommCmd_8h" ],
    [ "communication.cpp", "communication_8cpp.html", "communication_8cpp" ],
    [ "communication.h", "communication_8h.html", "communication_8h" ],
    [ "Control2WiFi.cpp", "Control2WiFi_8cpp.html", "Control2WiFi_8cpp" ],
    [ "Control2WiFi.h", "Control2WiFi_8h.html", "Control2WiFi_8h" ],
    [ "events.h", "events_8h.html", "events_8h" ],
    [ "socket_drv.cpp", "socket__drv_8cpp.html", null ],
    [ "socket_drv.h", "socket__drv_8h.html", "socket__drv_8h" ],
    [ "WebPanel.cpp", "WebPanel_8cpp.html", "WebPanel_8cpp" ],
    [ "WebPanel.h", "WebPanel_8h.html", "WebPanel_8h" ],
    [ "WiFi2Control.cpp", "WiFi2Control_8cpp.html", "WiFi2Control_8cpp" ],
    [ "WiFi2Control.h", "WiFi2Control_8h.html", "WiFi2Control_8h" ],
    [ "wifi_drv.cpp", "wifi__drv_8cpp.html", "wifi__drv_8cpp" ],
    [ "wifi_drv.h", "wifi__drv_8h.html", "wifi__drv_8h" ],
    [ "WiFiClient.cpp", "WiFiClient_8cpp.html", "WiFiClient_8cpp" ],
    [ "WiFiClient.h", "WiFiClient_8h.html", [
      [ "WiFiClient", "classWiFiClient.html", "classWiFiClient" ]
    ] ],
    [ "WiFiServer.cpp", "WiFiServer_8cpp.html", null ],
    [ "WiFiServer.h", "WiFiServer_8h.html", [
      [ "WiFiServer", "classWiFiServer.html", "classWiFiServer" ]
    ] ],
    [ "WiFiUdp.cpp", "WiFiUdp_8cpp.html", "WiFiUdp_8cpp" ],
    [ "WiFiUdp.h", "WiFiUdp_8h.html", "WiFiUdp_8h" ],
    [ "wl_definitions.h", "wl__definitions_8h.html", "wl__definitions_8h" ],
    [ "wl_types.h", "wl__types_8h.html", "wl__types_8h" ]
];