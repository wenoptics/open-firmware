var WiFi2Control_8h =
[
    [ "tsNetworkParams", "structtsNetworkParams.html", "structtsNetworkParams" ],
    [ "tsSockStatus", "structtsSockStatus.html", "structtsSockStatus" ],
    [ "WiFi2ControlClass", "classWiFi2ControlClass.html", "classWiFi2ControlClass" ],
    [ "CONNECTION_TIMEOUT", "WiFi2Control_8h.html#a0c63390af22aa0f877eece67372a7414", null ],
    [ "MAX_NETWORK_LIST", "WiFi2Control_8h.html#a1ca079faac5937dd224e346d841ccb81", null ],
    [ "MAX_PARAMS", "WiFi2Control_8h.html#a885a6481fc6d474d0be18bc0facf648d", null ],
    [ "MAX_SOCK_NUMBER", "WiFi2Control_8h.html#a0bbedd1c32c7d28e62e0f50c2a235f31", null ],
    [ "MTU_SIZE", "WiFi2Control_8h.html#a3ffe523b678f356880d424f19f481010", null ],
    [ "NO_SOCKET_AVAIL", "WiFi2Control_8h.html#a09dec3fce7faf6806f1f07ad4ecaa446", null ],
    [ "PROT_TCP", "WiFi2Control_8h.html#a56ceccbbb11411d125bf8aaf48fcac21", null ],
    [ "PROT_UDP", "WiFi2Control_8h.html#afb5ebfaff9a32a76648ad89c0ab05a11", null ],
    [ "WIFI_SPI_ACK", "WiFi2Control_8h.html#acd4b224f096b30f85affe787a1c68395", null ],
    [ "WIFI_SPI_ERR", "WiFi2Control_8h.html#af093db4732676ef177d94fe1a56cc799", null ],
    [ "ext_callback", "WiFi2Control_8h.html#a32774489a9f2b5c0f0922b397b0f3760", null ],
    [ "__attribute__", "WiFi2Control_8h.html#ad09246453a4dabd919c7541484046a87", null ],
    [ "tsNetArray", "WiFi2Control_8h.html#aecbaeac0464f8d6daee9ffae2c2dd6e1", null ],
    [ "tsNetParam", "WiFi2Control_8h.html#a4a2e9157a441d5faddc475ea3bf78d3e", null ],
    [ "tsParameter", "WiFi2Control_8h.html#a3885688bb9493b027cdb27a23a3d0149", null ],
    [ "wifi2control", "WiFi2Control_8h.html#a515783515458c562d6e4c6fb906264e2", null ]
];