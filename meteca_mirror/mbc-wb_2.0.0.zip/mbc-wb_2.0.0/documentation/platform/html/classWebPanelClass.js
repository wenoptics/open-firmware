var classWebPanelClass =
[
    [ "WebPanelClass", "classWebPanelClass.html#a696d234738b20bca6288760bf9c59da0", null ],
    [ "begin", "classWebPanelClass.html#a961e1e094286e1022983340fa315ab80", null ],
    [ "poll", "classWebPanelClass.html#a13230c9120befe79ded72cc5d705d625", null ]
];