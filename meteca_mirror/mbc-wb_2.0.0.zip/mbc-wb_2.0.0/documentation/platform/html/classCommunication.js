var classCommunication =
[
    [ "appendBuffer", "classCommunication.html#a3137df25dd09e15bd7f2efa996f4deb0", null ],
    [ "appendByte", "classCommunication.html#ad72b923b8e24bdc2694c86f34b4c367a", null ],
    [ "availGenericData", "classCommunication.html#a9f388b6e9151498c6aef4fed7b82ab14", null ],
    [ "clearResponseType", "classCommunication.html#a8cd85bba38729e8fb3794c8d6e283cc6", null ],
    [ "communicationBegin", "classCommunication.html#a2e5bbd92c367d94c92c7d658ad60eedc", null ],
    [ "getGenericData", "classCommunication.html#a75652f08947232a1cb3a58d0504bddae", null ],
    [ "getResponseType", "classCommunication.html#a291ee264dbef46ef09c3730f1a3f1d4d", null ],
    [ "getRxBuffer", "classCommunication.html#ab8fd407bc6d18b933335366b6e0b8912", null ],
    [ "handleCommEvents", "classCommunication.html#ab0e54265d77a4368b54c8adff6966cff", null ],
    [ "initExternalBuffer", "classCommunication.html#a9842b1d40fee0867a76817aa4c378fbb", null ],
    [ "registerCommand", "classCommunication.html#a2aeeba63d467c050681a5f2135336a0a", null ],
    [ "registerHandle", "classCommunication.html#a53722ef58d275f2870e956526ceae8fe", null ],
    [ "sendCmdPkt", "classCommunication.html#a9365d394a01fb982423e81a927521435", null ],
    [ "sendCommand", "classCommunication.html#ad859fa5e710e51efb9b0d023b9383f52", null ],
    [ "sendDataPkt", "classCommunication.html#aa8e7e66d3cdeee5f3384130fff14d152", null ],
    [ "sendGenericData", "classCommunication.html#af9f6a4dd037646e89881fcf897a99038", null ],
    [ "sendParam", "classCommunication.html#a192d1f46707326743415e3b4dc97fcad", null ],
    [ "sendParam", "classCommunication.html#a08d5356322c56b9399fe4ec19e2f4cff", null ],
    [ "communicationEvtCb", "classCommunication.html#a69cccf50fe5bd3cc8e34159cec7a9e26", null ]
];