var annotated_dup =
[
    [ "Communication", "classCommunication.html", "classCommunication" ],
    [ "Configuration", "classConfiguration.html", "classConfiguration" ],
    [ "Control2WiFi", "classControl2WiFi.html", "classControl2WiFi" ],
    [ "networkParams_s", "structnetworkParams__s.html", "structnetworkParams__s" ],
    [ "SocketDrv", "classSocketDrv.html", "classSocketDrv" ],
    [ "tsNetworkParams", "structtsNetworkParams.html", "structtsNetworkParams" ],
    [ "tsSockStatus", "structtsSockStatus.html", "structtsSockStatus" ],
    [ "WebPanelClass", "classWebPanelClass.html", "classWebPanelClass" ],
    [ "WiFi2ControlClass", "classWiFi2ControlClass.html", "classWiFi2ControlClass" ],
    [ "WiFiClient", "classWiFiClient.html", "classWiFiClient" ],
    [ "WiFiDrv", "classWiFiDrv.html", "classWiFiDrv" ],
    [ "WiFiServer", "classWiFiServer.html", "classWiFiServer" ],
    [ "WiFiUDP", "classWiFiUDP.html", "classWiFiUDP" ]
];