var WiFiUdp_8cpp =
[
    [ "_internalBufPtrUdp", "WiFiUdp_8cpp.html#a3b761c0606602184cd1709304b25f683", null ],
    [ "_internalBufSzUdp", "WiFiUdp_8cpp.html#a3dfb9e72de63707e746bc99887f89e4b", null ],
    [ "_internalBufUdp", "WiFiUdp_8cpp.html#acfd3c843b69e1f6879a99e239e08311a", null ],
    [ "_sockDataSzUdp", "WiFiUdp_8cpp.html#a692432eee5fb4d3979ea4902dddef2b5", null ]
];