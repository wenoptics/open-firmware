/*
  Meteca SA.  All right reserved.
  created by Dario Trimarchi and Chiara Ruggeri 2017-2018
  email: support@meteca.org

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "communication.h"
#include "Arduino.h"

uint8_t gpioData[4];

bool handle(){
  bool rep = true;
  communication._interface.prepareReplyBuf();

  // check if command belongs to the user-specified ones
  if(communication._tempPkt.cmd == CUSTOM_CMD_CODE){
	if (communication._tempPkt.cmdType == DATA_PKT && communication._interface.recPacket.endReceived == false) {
		if (communication._interface.socketPktPtr == 0) { // first packet. received size is 0
			communication._customCurrentCmd = communication._tempPkt.dataPtr[0];
			for(uint8_t i = 0; i < communication._cmdIndex; i++){
				if(communication._customCurrentCmd == communication._customCmdCode[i]){
					if(communication._custom_ext_buff[i] != NULL)
						memcpy(communication._custom_ext_buff[i], communication._tempPkt.dataPtr + 1, communication._tempPkt.nParam - 1);
					communication._interface.socketPktPtr = communication._tempPkt.nParam;
					break;
				}
			}
		} else {
			for(uint8_t i = 0; i < communication._cmdIndex; i++){ // intermediate chunk
				if(communication._customCurrentCmd == communication._customCmdCode[i]){
					if(communication._custom_ext_buff[i] != NULL)
						memcpy(communication._custom_ext_buff[i] + communication._interface.socketPktPtr - 1, communication._tempPkt.dataPtr, communication._tempPkt.nParam);
					communication._interface.socketPktPtr += communication._tempPkt.nParam;
					break;
				}		
			}
		}
	}
	else {
		if (communication._tempPkt.nParam == 255) { // 255 indicates a special case where data packet payload fits 1 packet
			uint8_t customCmd = communication._tempPkt.dataPtr[0];
			for(uint8_t i = 0; i < communication._cmdIndex; i++){
				if(customCmd == communication._customCmdCode[i]){
					if(communication._custom_ext_buff[i] != NULL)
						memcpy(communication._custom_ext_buff[i], communication._tempPkt.dataPtr + 1, communication._tempPkt.totalLen);
					communication._interface.socketPktPtr = communication._tempPkt.totalLen;
					// call user-defined function
					if(communication._userCallbacks[i] != NULL)
						communication._userCallbacks[i](communication._interface.socketPktPtr);
					break;
				}
			}
			communication._interface.socketPktPtr = 0;
		} else { // last packet
			for(uint8_t i = 0; i < communication._cmdIndex; i++){
				if(communication._customCurrentCmd == communication._customCmdCode[i]){
					if(communication._custom_ext_buff[i] != NULL)
						memcpy(communication._custom_ext_buff[i] + communication._interface.socketPktPtr - 1, communication._tempPkt.dataPtr, communication._tempPkt.nParam);
					communication._interface.socketPktPtr += communication._tempPkt.nParam;
					// call user-defined function
					if(communication._userCallbacks[i] != NULL)
						communication._userCallbacks[i](communication._interface.socketPktPtr - 1);
					break;
				}
			}
			communication._interface.socketPktPtr = 0;
		}
	}
	return false;
  }
  
  // check all other commands
  switch(communication._tempPkt.cmd){
	case NONE: // used for synchronization aim
		communication._interface.enableRx();
		communication._interface.ack();
	case GPIO_REQUEST:
		rep = communication._moveGpio();
	break;
	
	case GPIO_RESPONSE:
		memcpy(gpioData, &communication._tempPkt.dataPtr[1], 4); // consider 32-byte responses maximum
		communication._responseType = GPIO_RESPONSE;
	break;
	
	// process PUT_CUSTOM_DATA command sent from the other micro
	case PUT_CUSTOM_DATA:
		if (communication._tempPkt.cmdType == DATA_PKT && communication._interface.recPacket.endReceived == false) {
			if(communication._multipacket == false){ // first packet
				if(communication._user_ext_buff == NULL){ // create a safe place where storing data
					communication._user_ext_buff = (uint8_t*)malloc(communication._tempPkt.totalLen);
				}
				if(communication._user_ext_buff != NULL)
					memcpy(communication._user_ext_buff, communication._tempPkt.dataPtr, communication._tempPkt.nParam);
				communication._user_ext_buff_sz = communication._tempPkt.nParam;
				communication._multipacket = true;
			} else { // for all the other intermediate packet nParam will be BUFFER_SIZE
				if(communication._user_ext_buff != NULL)
					memcpy(communication._user_ext_buff + communication._user_ext_buff_sz, communication._tempPkt.dataPtr, communication._tempPkt.nParam);
				communication._user_ext_buff_sz += communication._tempPkt.nParam;
			}
		} else {
			if (communication._tempPkt.nParam == 255) { // 255 indicates a special case where data packet payload fits 1 packet
				if(communication._user_ext_buff == NULL){ // create a safe place where storing data
					communication._user_ext_buff = (uint8_t*)malloc(communication._tempPkt.totalLen + 1);
				}
				if(communication._user_ext_buff != NULL)
					memcpy(communication._user_ext_buff, communication._tempPkt.dataPtr, communication._tempPkt.totalLen + 1);
				communication._user_ext_buff_sz = communication._tempPkt.totalLen + 1;
			} else {
				if(communication._user_ext_buff != NULL)
					memcpy(communication._user_ext_buff + communication._user_ext_buff_sz, communication._tempPkt.dataPtr, communication._tempPkt.nParam);
				communication._user_ext_buff_sz += communication._tempPkt.nParam;
			}
			communication._multipacket = false;
		}
		rep = false;
	break;
	
	default:
		// call user defined handlers
		communication._responseType = NONE;
		rep = false;
		for(uint8_t i = 0; i < EXT_HANDLES; i++)
			if(communication._handleExt[i] != NULL){
				bool reply = communication._handleExt[i]();
				if(reply == true){
					// rep will be false only if all the external handler return false
					rep = true;
				}
			}
  }

  return rep;
}

void Communication::handleCommEvents(){
  // acquire lock
  if(getLock()){
	  bool replyReady = false;
	  if (_interface.canProcess()) {
		  
		while(_interface.canProcess()){
		  _interface.endProcessing();
		  if (_interface.read(&_tempPkt) == 0){
		   replyReady = handle();
		  }
		}

		_interface.enableRx(); // enable next packet reception

		if(_interface.notifyAck){
			_interface.notifyAck = false;
			_interface.ack();
		   }
	  }
	  
	  // release lock
	  releaseLock();
  }
}

void Communication::communicationBegin(){
  _interface.begin();
  _interface.prepareReplyBuf();
  _interface.enableRx();
  _mutex = xSemaphoreCreateRecursiveMutex();
  communication._ready = true;

}

bool Communication::registerHandle(bool(*func)(void)){
	bool registered = false;
	for(uint8_t i = 0; i < EXT_HANDLES; i++){
		// look for the first available space for the handle
		if(_handleExt[i] == NULL){
			_handleExt[i] = func;
			registered = true;
			break;
		}
	}
	return registered;
}

bool Communication::registerCommand(uint8_t cmdCode, ext_callback function, uint8_t* buffer){
	if(_cmdIndex == CUSTOM_CMD_NR)
		return false; // do not accept more than CUSTOM_CMD_NR commands
	
	for(uint8_t i = 0; i < _cmdIndex; i++){
		if(_customCmdCode[i] == cmdCode)
			return false; // do not accept an already assigned command code
	}
		
	if(buffer != NULL)
		_custom_ext_buff[_cmdIndex] = buffer;
	
	_customCmdCode[_cmdIndex] = cmdCode;
	_userCallbacks[_cmdIndex] = function;
	_cmdIndex++;
	return true;
}

void Communication::sendCommand(uint8_t cmdCode, uint8_t* data, uint32_t len){
  // acquire lock
  if(getLock()){
	handleCommEvents();
	
	bool existing = false;
	
	// check if cmdCode is an already registered one
	for(uint8_t i = 0; i < _cmdIndex; i++){
		if(_customCmdCode[i] == cmdCode){
			existing = true;
			break;
		}
	}
	if(!existing){ // do not send a command that has not been previously registered
		// release lock
		releaseLock();
		return;
	}

	communication.sendDataPkt(CUSTOM_CMD_CODE);
	communication.appendByte(cmdCode);
	communication.appendBuffer(data, len);
	communication.enableRx();
	// release lock
	releaseLock();
  }
}

void Communication::initExternalBuffer(uint8_t* extBuf){
	handleCommEvents();
    _user_ext_buff = extBuf;
}

int32_t Communication::availGenericData(void){
  // acquire lock
  if(getLock()){
    handleCommEvents();

    // check if there are new data for our socket
    if (_interface.recPacket.endReceived && _user_ext_buff_sz > 0) {
		// release lock
		releaseLock();
        return _user_ext_buff_sz;
    }
	// release lock
	releaseLock();
    return 0;
  }
  return 0;
}

uint32_t Communication::getGenericData(uint8_t *data, uint32_t len){
  // acquire lock
  if(getLock()){
	uint32_t size = _user_ext_buff_sz;
	if(data != NULL){
		// get minimum between len and _user_ext_buff_sz
		if(len > 0)
			size = (len > _user_ext_buff_sz) ? _user_ext_buff_sz : len;
		if(_user_ext_buff == NULL) // if user doens't register a buffer and malloc fails
			size = 0;
		memcpy(data, _user_ext_buff, size);
	}
	_user_ext_buff_sz = 0;
	// release lock
	releaseLock();
	return size;
  }
  return 0;
}

void Communication::sendGenericData(const char* data, uint32_t len){
  // acquire lock
  if(getLock()){
    handleCommEvents();
    
	communication.sendDataPkt(PUT_CUSTOM_DATA);
	communication.appendBuffer((uint8_t*)data, len);
	communication.enableRx();
	
	// release lock
	releaseLock();
  }
}

uint8_t Communication::getResponseType(){	  
	return _responseType;
}

void Communication::clearResponseType(){
	_responseType = NONE;
}

void Communication::sendCmdPkt(uint8_t cmd, uint8_t numParam){
  // acquire lock
  if(getLock()){
	_interface.sendCmd(cmd, numParam);
	// release lock
	releaseLock();
  }
}

void Communication::sendDataPkt(uint8_t cmd){
  // acquire lock
  if(getLock()){
	_interface.sendDataPkt(cmd);
	// release lock
	releaseLock();
  }
}

void Communication::sendParam(uint8_t *param, uint8_t param_len, uint8_t lastParam){
  // acquire lock
  if(getLock()){
	_interface.sendParam(param, param_len, lastParam);
	// release lock
	releaseLock();
  }
}

void Communication::sendParam(uint16_t param, uint8_t lastParam){
  // acquire lock
  if(getLock()){
	_interface.sendParam(param, lastParam);
	// release lock
	releaseLock();
  }
}

void Communication::appendByte(uint8_t data, uint8_t lastParam){
  // acquire lock
  if(getLock()){
	_interface.appendByte(data, lastParam);
	// release lock
	releaseLock();
  }
}

void Communication::appendBuffer(const uint8_t *data, uint32_t len){
  // acquire lock
  if(getLock()){
	_interface.appendBuffer(data, len);
	// release lock
	releaseLock();
  }
}

uint8_t* Communication::getRxBuffer(){
	return (uint8_t*)&_tempPkt;
}

bool Communication::endReceived(){
	return _interface.recPacket.endReceived;
}

void Communication::enableRx(){
	if(getLock()){
		_interface.enableRx();
		releaseLock();
	}
}

bool Communication::companionReady(){
	return _ready;
}

bool Communication::getLock(){
  // acquire lock
  if(_mutex != NULL && (xSemaphoreTakeRecursive(_mutex, ( TickType_t )(LOCK_TIMEOUT / portTICK_PERIOD_MS)) == pdTRUE))
		return true;
	return false;
}

void Communication::releaseLock(){
	// release lock
	xSemaphoreGiveRecursive(_mutex);
}

/*
* Process GPIO_REQUEST command by actuating the selected operation on the specified pin
*/
bool Communication::_moveGpio(){
	bool rep = false;
	uint8_t op = _tempPkt.dataPtr[1];
	uint8_t pin = _tempPkt.dataPtr[3];
	uint8_t mode;
	uint32_t val = 0;
	uint32_t result = 0;

	switch(op){
		case PIN_MODE: // pinMode command
			mode = _tempPkt.dataPtr[5]; 
			pinMode(pin, mode);
			_interface.notifyAck = true;
			rep = false; // no reply needed
		break;
		case WRITE_DIGITAL: // digitalWrite command
			val = _tempPkt.dataPtr[5] + (_tempPkt.dataPtr[6] << 8) + (_tempPkt.dataPtr[7] << 16) + (_tempPkt.dataPtr[8] << 24);
			digitalWrite(pin, val);
			_interface.notifyAck = true;
			rep = false;
		break;
		case WRITE_ANALOG: // analogWrite command
			val = _tempPkt.dataPtr[5] + (_tempPkt.dataPtr[6] << 8) + (_tempPkt.dataPtr[7] << 16) + (_tempPkt.dataPtr[8] << 24);
			analogWrite(pin, val);
			
			_interface.notifyAck = true;
			rep = false;
		break;
		case READ_DIGITAL: // digitalRead command	
			result = digitalRead(pin);
			rep = true;
		break;
		case READ_ANALOG: // analogRead commands
			result = analogRead(pin);
			rep = true;
		break;
		default:
			rep = false;
		break;
	}
	
	if(rep == true){
	  //set the response struct
	  sendCmdPkt(GPIO_RESPONSE, PARAM_NUMS_1);
	  sendParam((uint8_t*)&result, PARAM_SIZE_4, LAST_PARAM);
	}
	
	return rep;
}

Communication communication;


/*
* Activate pinMode function on one of the pin connected to the companion chip
*
* param op: a code representing the operation to be performed
* param pin: pin on which operation has to take effect
* param mod: mode applied to pin (e.g. OUTPUT, INPUT and so on)
*/
extern "C" void sendGPIOMode(uint8_t op, uint8_t pin, uint8_t mod){
  communication.handleCommEvents();

  if(communication.getLock()){
	  communication.sendCmdPkt(GPIO_REQUEST, PARAM_NUMS_3);
	  communication.sendParam(&op, PARAM_SIZE_1, NO_LAST_PARAM);
	  communication.sendParam(&pin, PARAM_SIZE_1, NO_LAST_PARAM);
	  communication.sendParam(&mod, PARAM_SIZE_1, LAST_PARAM);
	  communication.enableRx();
	  communication.releaseLock();
  }
}

/*
* Activate digitalWrite or analogWrite function on one of the pin connected to the companion chip
*
* param op: a code representing the operation to be performed (WRITE_DIGITAL or WRITE_ANALOG)
* param pin: pin on which operation has to take effect
* param mod: value to be applied to pin
*/
extern "C" void sendGPIOWrite(uint8_t op, uint8_t pin, uint32_t val){
  communication.handleCommEvents();

  if(communication.getLock()){
	  communication.sendCmdPkt(GPIO_REQUEST, PARAM_NUMS_3);
	  communication.sendParam(&op, PARAM_SIZE_1, NO_LAST_PARAM);
	  communication.sendParam(&pin, PARAM_SIZE_1, NO_LAST_PARAM);
	  communication.sendParam((uint8_t*)&val, PARAM_SIZE_4, LAST_PARAM);
	  communication.enableRx();
	  communication.releaseLock();
  }
}

/*
* Activate digitalRead or analogRead function on one of the pin connected to the companion chip
*
* param op: a code representing the operation to be performed (READ_DIGITAL or READ_ANALOG)
* param pin: pin on which operation has to take effect
*
* return: the read value
*/
extern "C" int32_t sendGPIORead(uint8_t op, uint8_t pin){
  communication.handleCommEvents();

  if(communication.getLock()){
	  communication.sendCmdPkt(GPIO_REQUEST, PARAM_NUMS_2);
	  communication.sendParam(&op, PARAM_SIZE_1, NO_LAST_PARAM);
	  communication.sendParam(&pin, PARAM_SIZE_1, LAST_PARAM);
	  communication.enableRx();
	  communication.releaseLock();
  }
    // Poll response for the next 2 seconds
    uint32_t start = millis();
    while (((millis() - start) < 2000)) {
        communication.handleCommEvents();
        if (communication.getResponseType() == GPIO_RESPONSE) {
			communication.clearResponseType();
			uint32_t result = gpioData[0] + (gpioData[1] << 8) + (gpioData[2] << 16) + (gpioData[3] << 24);
			return result;
        }
    }
    return -1;
}