#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_task_wdt.h"
#include "Arduino.h"

#include "communication.h"

// Arduino IDE doesn't compile included libraries from core
// force compiling of the following libraries
#include "ArduinoOTA.cpp"
#include "WiFiUdp.cpp"
#include "Updater.cpp"
#include "ESPmDNS.cpp"
#include "WiFiClient.cpp"
#include "WiFi.cpp"
#include "WiFiGeneric.cpp"
#include "WiFiSTA.cpp"
#include "WiFiAP.cpp"
#include "WiFiScan.cpp"
#include "WiFiServer.cpp"
#include "WiFiMulti.cpp"
#include "WiFiClientSecure.cpp"
#include "ssl_client.cpp"

TaskHandle_t loopTaskHandle = NULL;

#if CONFIG_AUTOSTART_ARDUINO

bool loopTaskWDTEnabled;

SemaphoreHandle_t UARTmutex;

// ---------------------------------------------- OTA Task
void OTATask(void *pvParameters)
{
  #ifdef OTA_RUNNING
    ArduinoOTAClass internalOTA;
    internalOTA.begin();
  #endif
  
  while (1) {
    #ifdef OTA_RUNNING
   	  internalOTA.handle();
    #endif
    vTaskDelay(1);
    communication.handleCommEvents();
  }
}


void loopTask(void *pvParameters)
{	
	setup();
    for(;;) {
		if(loopTaskWDTEnabled){
            esp_task_wdt_reset();
		}
        loop();
    }
}

extern "C" void app_main()
{
	loopTaskWDTEnabled = false;
    initArduino();
	UARTmutex = xSemaphoreCreateRecursiveMutex();
	communication.communicationBegin();
	#ifdef OTA_RUNNING
		IPAddress default_IP(192,168,240,1);
		WiFi.begin();
		WiFi.mode(WIFI_AP_STA);
		WiFi.disconnect();
		delay(100);
		WiFi.softAPConfig(default_IP, default_IP, IPAddress(255, 255, 255, 0));   //set default ip for AP mode
		String mac = WiFi.macAddress();
		char softApssid []= {'M', 'B', 'C', '-', 'W', 'B', '-', mac[9], mac[10], mac[12], mac[13], mac[15], mac[16], '\0'};
		WiFi.softAP(softApssid);
	#endif

	xTaskCreateUniversal(loopTask, "loopTask", 8192, NULL, 1, &loopTaskHandle, CONFIG_ARDUINO_RUNNING_CORE);
	//create a task that will manage OTA update and communication events, with priority 1 and executed on core 0
	xTaskCreateUniversal(OTATask, "OTATask", 10000, NULL, 1, NULL, 0);
}
	
#endif