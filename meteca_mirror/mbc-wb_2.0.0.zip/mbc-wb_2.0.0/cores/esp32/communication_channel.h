/*
  Meteca SA.  All right reserved.
  created by Dario Trimarchi and Chiara Ruggeri 2017-2018
  email: support@meteca.org

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef COMM_CHANNEL_H
#define COMM_CHANNEL_H

// Select channel used by the two microcontroller to communicate each other.
// Currently available channel are SPI and UART.

// comment out following row to enable UART channel
//#define ESP_CH_UART

// comment out following row to enable SPI channel
#define ESP_CH_SPI

// check that just one channel is used at the same time
#if defined(ESP_CH_SPI) && defined(ESP_CH_UART)
#error "Please select just one communication interface (ESP_CH_SPI or ESP_CH_UART) in communication_channel.h file"
#endif

#endif // COMM_CHANNEL_H