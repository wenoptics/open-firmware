/*
  Meteca SA.  All right reserved.
  created by Dario Trimarchi and Chiara Ruggeri 2017-2018
  email: support@meteca.org

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "communication_channel.h"

#if defined(ESP_CH_SPI)

#include "SPISlave.h"
#include "SPISlave.cpp" // force SPISlave library compiling
#include "spi_drv.h"
#include "driver/periph_ctrl.h"

volatile bool SpiDrv::_rxEnabled = true;
volatile bool SpiDrv::_slaveSelected = false;
volatile uint8_t SpiDrv::_processing;
volatile bool SpiDrv::_sendingWait;
volatile bool SpiDrv::_dataArrived = false;
uint32_t srTimer = 0;

// -------------------------------------------------- CALLBACK --------------------------------------------------
/*
* ----------------------------------------------------- SS handler
*/

void handleSSInterrupt(void)
{
 if (digitalRead(SS) == LOW){
    SpiDrv::_slaveSelected = true;
  }
  else{  
    SpiDrv::_slaveSelected = false;
  }
}

/*
 * ---------------------------------------------------- SPI transfer complete handler
 */
 
void onDataTransferred(uint8_t transferredBytes, bool received){
  if(transferredBytes == 0){ // occasionally occurs
    SPISlave.enableRx(); // enable next packet reception
	SpiDrv::_rxEnabled = true;
    return;
  }
  if(received){
	SpiDrv::enableProcess();
	SpiDrv::_dataArrived = true;
  }
  SpiDrv::_sendingWait = false;
  SpiDrv::_rxEnabled = false;
}

// ----------------------------------------------- SpiDrv -----------------------------------------------
// ----------------------------------------------------- PRIVATE
/*
*
*/
SpiDrv::SpiDrv()
{
  _processing = 0;
  longCmd.totalLen = 0;
  recPacket.receivedLen = 0;
  recPacket.endReceived = true;
}

/*
* 
*/
void SpiDrv::_setSR(bool level)
{
    uint32_t deltaT = micros() - srTimer;

    if(deltaT < 10)
      delayMicroseconds(10 - deltaT);
  
  digitalWrite(PIN_SPI_SR, level);
  srTimer = micros();
}

/* -----------------------------------------------------------------
* Initializes the _repPkt buffer with the b byte and sets the buffer index to 1;
*/
void SpiDrv::_txBufInitWByte(uint8_t b)
{
	_repPkt[0] = b;
	_txIndex = 1;
	_pktType = b;
}

/* -----------------------------------------------------------------
* Appends to the _repPkt buffer a new b byte if there's enough space;
*
* return: (boolean)
*		  true byte queued
*		  false otherwise.
*/
bool SpiDrv::_txBufAppendByte(uint8_t b)
{
	if (_txIndex < MAX_CMD_LEN) {
		_repPkt[_txIndex++] = b;
		return true;
	}
	return false;
}

/* -----------------------------------------------------------------
* Set the overall len of the command packet
*/
void SpiDrv::_txBufSetOverallLen()
{
	if(_pktType == DATA_PKT){ // len is 4 bytes
		_repPkt[2] = _txIndex & 0xFF;
		_repPkt[3] = (_txIndex >> 8) & 0xFF;
		_repPkt[4] = (_txIndex >> 16) & 0xFF;
		_repPkt[5] = (_txIndex >> 24) & 0xFF;
	}
	else // len is 1 byte
		_repPkt[2] = _txIndex;
}


/* -----------------------------------------------------------------
* Finalizes the packet adding the END_CMD and writing out the command
*/
void SpiDrv::_txBufFinalizePacket()
{
	// add the END_CMD to the buffer
	_txBufAppendByte(END_CMD);
	
	_txBufSetOverallLen();
	
	// write out the data (32 byte minimum) to companion chip
	write(_repPkt, _txIndex);

}

// ----------------------------------------------------- PUBLIC
/*
*
*/
void SpiDrv::begin()
{
  pinMode(SS, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(SS), handleSSInterrupt, CHANGE);
  pinMode(PIN_SPI_SR, OUTPUT);
  digitalWrite(PIN_SPI_SR, LOW);
  _slaveSelected = false;
  SPISlave.setOnDataTrasnferred(onDataTransferred); // this function will be called for every communication on SPI bus
  SPISlave.setRxBuffer((uint8_t *)_raw_pkt[0], &_recvByte);
  Serial.begin(115200); // part of workaround to use GPIO0 as handshake pin.
  SPISlave.begin(MOSI, MISO, SCK, SS, PIN_SPI_HANDSHAKE);
  // The following workaround is needed to use GPIO0 as handshake pin in SPI communication.
  // It seems that if SPISlave library is used GPIO0 is always HIGH,
  // but if serial communication is initialized before and after the SPISlave.begin function this issue does not occur.
  // Why?
  Serial.begin(115200);
  Serial.end();
  periph_module_disable( PERIPH_UART0_MODULE );
  delay( 20 );
  periph_module_enable( PERIPH_UART0_MODULE );
  periph_module_disable( PERIPH_UART1_MODULE );
  delay( 20 );
  periph_module_enable( PERIPH_UART1_MODULE );
  periph_module_disable( PERIPH_UART2_MODULE );
  delay( 20 );
  periph_module_enable( PERIPH_UART2_MODULE );
}

/*
*
*/
void SpiDrv::enableProcess()
{
  _processing++;
}

/*
*
*/
uint8_t SpiDrv::canProcess()
{
  return _processing;
}

/*
*
*/
void SpiDrv::endProcessing()
{
  if(_processing > 0)
	_processing--;
}

/*
*
*/
void SpiDrv::ack(){
	// the following operation is time critical. Suspend scheduler on this core as to avoid interruptions
	vTaskSuspendAll();
	_setSR(HIGH);
    _setSR(LOW);
	// resume scheduler
	xTaskResumeAll();
}

/*
*
*/
void SpiDrv::enableRx(){
	if(!_rxEnabled){
      if(SPISlave.enableRx() == 0)
		_rxEnabled = true;
	}
	if(_suspended){
		_suspended = false;
		xTaskResumeAll();
	}
}

/*
*
*/
int8_t SpiDrv::read(tsNewCmd *_pkt)
{
  uint8_t* pktPtr = _raw_pkt[0];
  if(_processing > 0){ // if there's more than a packet to process, start with the oldest one
	pktPtr = _raw_pkt[1];
	_isBufferValid = true; // signal that _raw_pkt[0] still contains valid data
  }
 // ---------------------------------------------------------------------------- receiving long command packets
  if (recPacket.receivedLen > 0) {
    uint8_t endOffset;
    
	// check if END_CMD is in the last 4 received bytes (in the worst case there's a 4-byte 0 padding)
    for (uint8_t i = 1; i <= 4; i++) {
      if (pktPtr[_recvByte - i] == END_CMD) {
        endOffset = _recvByte - i;

        if (recPacket.receivedLen + endOffset == recPacket.totalLen - 1) {
          recPacket.endReceived = true;
          notifyAck = true;
          _pkt->cmdType = recPacket.cmdType;
          _pkt->cmd = recPacket.cmd;
          _pkt->nParam = endOffset;
          _pkt->totalLen = recPacket.totalLen - DATA_HEAD_FOOT_LEN;
          _pkt->dataPtr = &pktPtr[0];

          recPacket.receivedLen = recPacket.totalLen = 0;

          return 0;
        }
      }
    }
    if (recPacket.endReceived == false) {
      recPacket.receivedLen += _recvByte;

      if(recPacket.receivedLen >= recPacket.totalLen){
        recPacket.endReceived = true;
        recPacket.receivedLen = recPacket.totalLen = 0;
      }
      
      _pkt->cmdType = recPacket.cmdType;
      _pkt->cmd = recPacket.cmd;
      _pkt->totalLen = recPacket.totalLen - DATA_HEAD_FOOT_LEN;
      _pkt->nParam = _recvByte;
      _pkt->dataPtr = &pktPtr[0];

      notifyAck = true; 
      return 0;
    }
  }
  // ---------------------------------------------------------------------------- decoding command
  else if (pktPtr[0] == START_CMD || _multiPktCmd) {
    if(_multiPktCmd){
      uint8_t offset = 4; // 4 bytes were already removed from the message (command header)
      // copy the new part of the message
      memcpy((longCmd.dataPtr + _rxLen - offset), pktPtr, _recvByte);
      _rxLen += _recvByte;
      if(longCmd.totalLen <= _rxLen){ 
        // the whole message was received - check for end cmd and return the result
        _multiPktCmd = 0;
        if(longCmd.dataPtr[longCmd.totalLen - 5] != END_CMD){
		  enableRx(); // enable next packet reception
          return -1;
        }
        _pkt->cmdType = longCmd.cmdType;
        _pkt->cmd = longCmd.cmd;
        _pkt->totalLen = longCmd.totalLen;
        _pkt->nParam = longCmd.nParam;
        _pkt->dataPtr = longCmd.dataPtr;
        notifyAck = true;
        return 0;
      }
      if(++_multiPktCmd == 4){
        // we reached the maximum cmd len size and we still didn't find end cmd. Maybe an error occurred
        _multiPktCmd = 0;
		enableRx(); // enable next packet reception
		return -1;
      }
    }

    _pkt->cmdType = pktPtr[0];
    _pkt->cmd = pktPtr[1];
    _pkt->totalLen = (uint32_t)pktPtr[2];
    _pkt->nParam = pktPtr[3];
    _pkt->dataPtr = &pktPtr[4];
    
    if (_pkt->totalLen > _recvByte) {
      longCmd.cmdType = _pkt->cmdType;
      longCmd.cmd = _pkt->cmd;
      longCmd.totalLen = _pkt->totalLen;
      longCmd.nParam = _pkt->nParam;

      uint16_t payLoadLen = _recvByte - 4;
      _rxLen = _recvByte;

      // copy total len - cmd header size
      memset(_longCmdPkt, 0, BUFFER_SIZE << 2); // clear buffer, max cmd len = 4 * BUFFER_SIZE
      longCmd.dataPtr = _longCmdPkt;
      memcpy(longCmd.dataPtr, _pkt->dataPtr, payLoadLen);
     
      notifyAck = true; 
	  enableRx(); // enable next packet reception
	 
      _multiPktCmd = 1;

      return -1;
    }
    else {
      if (pktPtr[_pkt->totalLen - 1] != END_CMD){
		enableRx(); // enable next packet reception
        return -1;
      }
      return 0;
    }
  }
  // ---------------------------------------------------------------------------- decoding data packets
  else if (pktPtr[0] == DATA_PKT)
  {
	 
    _pkt->cmdType = recPacket.cmdType = pktPtr[0];
    _pkt->cmd = recPacket.cmd = pktPtr[1];
    recPacket.receivedLen = _recvByte;
    recPacket.totalLen = (pktPtr[5] << 24) + (pktPtr[4] << 16) + (pktPtr[3] << 8) + pktPtr[2];
    recPacket.endReceived = false;
    _pkt->totalLen = recPacket.totalLen - DATA_HEAD_FOOT_LEN;
        // 32 byte - (cmdType (1 byte) + cmd (1 byte) + totalLen (4 byte)) = 32 - 6 = 26
    _pkt->nParam = recPacket.receivedLen - (sizeof(recPacket.cmdType) + sizeof(recPacket.cmd) + sizeof(recPacket.totalLen)); //_pkt->nParam = 26;
    _pkt->dataPtr = &pktPtr[6];

	// check if END_CMD is in the last 4 received bytes (at least there's a 4-byte 0 padding)
    for(uint8_t i = 1; i <= 4; i++){
      if(pktPtr[_recvByte - i] == END_CMD){
        recPacket.endReceived = true;
        recPacket.receivedLen = recPacket.totalLen = 0;
        _pkt->nParam = 255; // this value is used as flag that indicates that data packet is all contained in a single packet
        break;
      }
    }
			
    notifyAck = true; 
    return 0;
  }
  // error;
  else { 
    return -1;
  }

  return 0;
}

/*
*
*/
void SpiDrv::write(uint8_t *_rep, uint32_t len)
{
   // safety check
  if(_suspended){
    xTaskResumeAll();
    _suspended = false;
  }

  // first of all check if the spi buffer needs to be empty
  // (probably it has been filled before in order to be able to receive new packet from master)
  if(_rxEnabled == true){
	_dataArrived = false; // used to check if valid data arrive in the next transaction
    // if the SPI buffer was already been set, trigger a read to flush it  
    _sendingWait = true;
    uint32_t timeout = millis() + 1000;
    _setSR(HIGH);
    while(_sendingWait && timeout > millis());
    _setSR(LOW);
	// save packet received during this transaction for further processing, if needed
	if(_dataArrived)
	  memcpy(_raw_pkt[1], _raw_pkt[0], 128);
  }
  
  if(_isBufferValid){
	  // in the last processing we parsed _raw_pkt[1]. Save _raw_pkt[0] into _raw_pkt[1] to avoid _raw_pkt[0] be overridden by the next transaction
	  _isBufferValid = false;
	  memcpy(_raw_pkt[1], _raw_pkt[0], 128);
  }
  
  // calculate the number of packets to be sent - each packet is 32 byte long
  uint8_t nPacket = (uint8_t)(len >> 5);
  uint8_t remainingByte = 0;
  uint32_t pktOffset = 0;
  uint32_t t = 0;
  uint8_t tempBuf[33] = {0};
  bool multipacket = false;
  uint16_t sentByte = 0 ;
  bool firstPacket = true;
  
  if ((remainingByte = (len % 32)) > 0)
    nPacket++;
  
  if(nPacket > 1) {
    multipacket = true;
  }
  
  while (nPacket > 0) {
    if(nPacket == 1 && remainingByte > 0) {
      memcpy(tempBuf, (uint8_t *)(_rep + pktOffset), remainingByte);
      esp_err_t err_code = SPISlave.setData(tempBuf, 32, SPI_TIMEOUT);
      _rxEnabled = true;
	  if(err_code != ESP_OK){
        #ifdef DEBUG_SERIALE
          Serial.println("Stop waiting write 1");
          Serial.println("Byte written so far: " + String(sentByte));
        #endif
		return;
      }
      sentByte += remainingByte;
    }
    else{
	  esp_err_t err_code = SPISlave.setData((uint8_t *)(_rep + pktOffset), 32, SPI_TIMEOUT); //send response to MCU      
      _rxEnabled = true;
	  if(err_code != ESP_OK){
        #ifdef DEBUG_SERIALE
          Serial.println("Stop waiting write");
          Serial.println("Byte written so far: " + String(sentByte));
        #endif
		return;
      }
      sentByte += 32;
    }

    t = millis() + SPI_TIMEOUT;

    // if I need to trigger ISR for data read..
    // I check that every running process (e.g. a write) is finished..
    if (_slaveSelected == true) {
      while(!multipacket && !canProcess() && _slaveSelected == true && t > millis());
      if(t <= millis()) {
        // lower the ISR signal to let the 328 know that ESP is already idle
        _setSR(LOW);
        return;
      }
    }

    // between setting the buffer and raising SR high, master could have already read the message during a write.
    // in this case don't set SR but go ahead.
    if(_rxEnabled){
      _sendingWait = true;
      // set the ISR trigger signal to fire a read process
      _setSR(HIGH);
      
      
      pktOffset += 32;
      nPacket--;

      t = millis() + SPI_TIMEOUT;
      while (_sendingWait) {
  
        if (t <= millis()) {
  #ifdef DEBUG_SERIALE
          Serial.println("Stop waiting write 3");
          Serial.println("Byte written so far: " + String(sentByte));
  #endif
          // lower the ISR signal to let the 328 know that ESP is already idle
          _setSR(LOW);
		  return;
        }
      }
	  // lower the ISR signal to let the 328 know that ESP is already idle
      _setSR(LOW);
    }
  }
  vTaskSuspendAll();
  _suspended = true;
  #ifdef DEBUG_SERIALE
//  Serial.println("byte written: " + String(sentByte));
  #endif
}

void SpiDrv::clearRx(){
    memset(_raw_pkt, 0, BUFFER_SIZE);
}


/* Cmd Struct Message
*  _________________________________________________________________________________ 
* | START CMD | C/R  | CMD  |[TOT LEN]| N.PARAM | PARAM LEN | PARAM  | .. | END CMD |
* |___________|______|______|_________|_________|___________|________|____|_________|
* |   8 bit   | 1bit | 7bit |  8bit   |  8bit   |   8bit    | nbytes | .. |   8bit  |
* |___________|______|______|_________|_________|___________|________|____|_________|
*/
/* Data Struct Message
* __________________________________________________________________________________
*| DATA PKT  | C/R  | CMD  |  OVERALL  |  SOCKET  |  PAYLOAD  | .. |  END DATA PKT |
*|___________|______|______|___ LEN____|__________|___________|____|_______________|
*|   8 bit   | 1bit | 7bit |   32bit   |  8 bit   |   nbytes  | .. |      8bit     |
*|___________|______|______|___________|__________|___________|____|_______________|
*/


/* -----------------------------------------------------------------
* Prepares the _repPkt to be sent as a new command to companion chip
* It requires also the number of attached parameters.
*/
void SpiDrv::sendCmd(uint8_t cmd, uint8_t numParam)
{
	// init the buffer (32 bytes) with the START_CMD
	_txBufInitWByte(START_CMD);
	// attach the cmd + REPLY_FLAG
	_txBufAppendByte(cmd | REPLY_FLAG);
	// put the space for the overall len - 1 byte
	_txBufAppendByte(0);
	// add the number of parameters
	_txBufAppendByte(numParam);
	
	// if no parameters
	if (numParam == 0) {
		_txBufFinalizePacket();
	}
}

/* -----------------------------------------------------------------
* Prepares the _repPkt to be sent as a new data pkt to companion chip
* It requires also the number of attached parameters.
*/
void SpiDrv::sendDataPkt(uint8_t cmd)
{
	// init the buffer (32 bytes) with the START_CMD
	_txBufInitWByte(DATA_PKT);
	// attach the cmd + the complement of the REPLY_FLAG
	_txBufAppendByte(cmd | REPLY_FLAG);
	// put the space for the overall len - 4 byte
	_txBufAppendByte(0);
	_txBufAppendByte(0);
	_txBufAppendByte(0);
	_txBufAppendByte(0);
}

/* -----------------------------------------------------------------
* Add parameters to the command buffer for the companion chip
* It requires also the lastParam parameter to understand which is the last one.
*/
void SpiDrv::sendParam(uint16_t param, uint8_t lastParam)
{
	// NOTE for each append be sure to not insert more than buffer size bytes in buffer or append function
	// won't let me do that.
	
	// since each parameter is two bytes wide, add 2 as the parameter size
	_txBufAppendByte(2);
	// then add the parameter (big-endian mode) 
	_txBufAppendByte((uint8_t)((param & 0xff00) >> 8));
	_txBufAppendByte((uint8_t)(param & 0xff));

	// if this is the last parameter
	if (lastParam == 1) {
		_txBufFinalizePacket();
	}
}

/* -----------------------------------------------------------------
* Add a list of parameters to the command buffer for the companion chip (overload)
* It requires the parameter's list (*param), the length of each parameter (param_len)
* and also the lastParam parameter to understand if this is the last one.
*/
void SpiDrv::sendParam(uint8_t *param, uint8_t param_len, uint8_t lastParam)
{
	// NOTE for each append be sure to not insert more than buffer size byte in buffer or append function
	// won't let me do that.
	
	// append the typ. parameter size (1 byte)
	_txBufAppendByte(param_len);

	// append all the parameters from the list to the buffer
	for (uint16_t i = 0; i < param_len; ++i) {
		_txBufAppendByte(param[i]);
	}

	// if this is the last parameter
	if (lastParam == 1) {
		_txBufFinalizePacket();
	}
}


/* -----------------------------------------------------------------
* Add byte to the command buffer for the companion chip
* It requires also the lastParam parameter to understand which is the last one.
*/
void SpiDrv::appendByte(uint8_t data, uint8_t lastParam){
	_txBufAppendByte(data);
	
	// if this is the last parameter
	if (lastParam == 1) {
		_txBufFinalizePacket();
	}
}

/* -----------------------------------------------------------------
* Add a buffer to the command for the companion chip and send the so created packet
*/
void SpiDrv::appendBuffer(const uint8_t *data, uint32_t len){
	// calculate and send the overall length
	uint32_t totalLen = _txIndex + len + 1; // 1 byte more to store end command byte
	if(_pktType == DATA_PKT){ // len is 4 bytes
		_repPkt[2] = totalLen & 0xFF;
		_repPkt[3] = (totalLen >> 8) & 0xFF;
		_repPkt[4] = (totalLen >> 16) & 0xFF;
		_repPkt[5] = (totalLen >> 24) & 0xFF;
	}
	else // len is 1 byte
		_repPkt[2] = totalLen;
		
	_writeBuffPkt(data, totalLen, _txIndex);
}


/*
* Prepare and send a data packet with command and data passed as argument.
*
* param cmdCode: command code that will be put in packet header
* param data: pointer to the data to be sent
* param len: data length
*/
void SpiDrv::_writeBuffPkt(const uint8_t *data, uint32_t len, uint8_t offset){	
	len -= offset; // remove size of the bytes already in the buffer;

	// if len is greater than _interface.repPkt size, split message in different writes
	uint16_t availDataSpace = MAX_CMD_LEN - (offset + 1); // don't consider header (offset) and footer for the first write
	uint32_t byteWritten = 0;
	while(len > availDataSpace){
		// be sure to send a BUFFER_SIZE multiple in order to avoid 0 padding for this communication
		// in this way control chip will not notice difference between sending the whole message and split message in multiple writes
		uint16_t writeLen = ((uint16_t)(availDataSpace + 1) / BUFFER_SIZE) * BUFFER_SIZE;		 
		memcpy((_repPkt + _txIndex), (data + byteWritten), writeLen - offset); // remove the already used space for header
		write(_repPkt, writeLen);
		byteWritten += writeLen;
		len -= writeLen;
		_txIndex = 0;
		availDataSpace = MAX_CMD_LEN - 1; // take into account space for end command
		offset = 0; // don't consider offset for next iterations	
	}
	
	// at this point _interface.repPkt has enough space to store the whole message (or the remaining part)
	memcpy((_repPkt + _txIndex), (data + byteWritten), len);
	_txIndex += len;
	_repPkt[_txIndex - 1] = END_CMD;

	write(_repPkt, _txIndex);
}

/*
* Initialize buffer used to store commands' reply.
*/
void SpiDrv::prepareReplyBuf(){
	_txPktSize = 0;
	memset(_repPkt, 0, MAX_CMD_LEN);
}

#endif