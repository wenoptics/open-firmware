/*
  Meteca SA.  All right reserved.
  created by Dario Trimarchi and Chiara Ruggeri 2017-2018
  email: support@meteca.org

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "communication_channel.h"

#if defined(ESP_CH_SPI)

#ifndef SPI_DRV
#define SPI_DRV

#include <stdint.h>
#include "spi_def.h"
#include "SPISlave.h"

#define NO_LAST_PARAM       0
#define LAST_PARAM          1

/*
*
*/
class SpiDrv {

  private:
    uint8_t _raw_pkt[2][BUFFER_SIZE]; //SPI buffer (limited to 128 bytes)
	uint8_t _recvByte = 0;
	uint8_t _longCmdPkt[MAX_CMD_LEN];
    uint16_t _rxLen = 0;  // size doesn't match maximum dimension of data that could be received from a DATA_PKT
    volatile static uint8_t _processing;
    uint8_t _multiPktCmd = 0;
	volatile static bool _rxEnabled;
	volatile static bool _slaveSelected;
	uint8_t _repPkt[MAX_CMD_LEN]; //response array
	uint32_t _txPktSize;
	uint32_t _txIndex;
	uint8_t _pktType = START_CMD;
    volatile static bool _sendingWait;
	bool _suspended = false;
	bool _isBufferValid = false;
	volatile static bool _dataArrived;

	void _setSR(bool level);

	void _txBufInitWByte(uint8_t b);
	bool _txBufAppendByte(uint8_t b);
	void _txBufFinalizePacket();
	void _txBufSetOverallLen();
	
	void _writeBuffPkt(const uint8_t *data, uint32_t len, uint8_t offset);
	
	friend void onDataTransferred(uint8_t transferredBytes, bool received);
	friend void handleSSInterrupt(void);

  public:
    tsDataPacket recPacket;
    tsNewCmd longCmd;
    uint32_t socketPktPtr = 0;
	bool notifyAck = false;
    
    SpiDrv();
    void begin();
    uint8_t canProcess();
    static void enableProcess();
    void end();
    void endProcessing();
    
    int8_t read(tsNewCmd *_pkt);
    void write(uint8_t *_rep, uint32_t len);
	void ack(void);
	void enableRx();
  	
	// command related functions
	//void sendBuffer(uint8_t *param, uint16_t param_len, uint8_t lastParam = NO_LAST_PARAM);
	void sendCmd(uint8_t cmd, uint8_t numParam);
	void sendDataPkt(uint8_t cmd);
	void sendParam(uint8_t *param, uint8_t param_len, uint8_t lastParam = NO_LAST_PARAM);
	void sendParam(uint16_t param, uint8_t lastParam = NO_LAST_PARAM);
	void appendByte(uint8_t data, uint8_t lastParam);
	void appendBuffer(const uint8_t *data, uint32_t len);
	
	void prepareReplyBuf();
    void clearRx(void);
};

#endif //SPI_DRV
#endif //ESP_CH_SPI