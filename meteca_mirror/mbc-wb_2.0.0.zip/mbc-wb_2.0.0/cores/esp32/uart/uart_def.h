/*
  Meteca SA.  All right reserved.
  created by Dario Trimarchi and Chiara Ruggeri 2017-2018
  email: support@meteca.org

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef UART_DEF_H
#define UART_DEF_H

#define PIN_SPI_SR          ACK_PIN
#define PIN_SPI_HANDSHAKE   BOOT


#define BUFFER_SIZE         255
#define UART_TIMEOUT        1000

#define START_CMD           0xe0
#define DATA_PKT            0xf0
#define END_CMD             0xee
#define ERR_CMD             0xef

#define CMD_FLAG            0
#define REPLY_FLAG          1<<7
#define DATA_FLAG           0x40

#endif