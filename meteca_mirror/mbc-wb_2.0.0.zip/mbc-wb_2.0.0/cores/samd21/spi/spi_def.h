/*
  Meteca SA.  All right reserved.
  created by Dario Trimarchi and Chiara Ruggeri 2017-2018
  email: support@meteca.org

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef SPI_DEF_H
#define SPI_DEF_H

#define START_CMD   	0xe0
#define DATA_PKT		0xf0
#define END_CMD     	0xee
#define ERR_CMD   		0xef
#define CMD_POS			1		// Position of Command OpCode on SPI stream
#define PARAM_LEN_POS 	2		// Position of Param len on SPI stream

#define BUF_SIZE	32
#define SPI_MAX_TX_SIZE	128

#endif // SPI_DEF_H