/*
  Meteca SA.  All right reserved.
  created by Dario Trimarchi and Chiara Ruggeri 2017-2018
  email: support@meteca.org

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "communication_channel.h"

#if defined(ESP_CH_SPI)

#include "Arduino.h"
#include "spi_drv.h"
#include <SPI.h>
#include "SPI.cpp" // force SPISlave library compiling
#include "pins_arduino.h"

static tpDriverIsr spiIsr;

volatile bool srLevel = false;
volatile bool SpiDrv::_interruptReq = false;

SPIClass intSPI (&PERIPH_SPI1, PIN_SPI1_MISO, PIN_SPI1_SCK, PIN_SPI1_MOSI, PAD_SPI1_TX, PAD_SPI1_RX);

void interruptFunction(void){
	if (digitalRead(SLAVEREADY) == HIGH) {
		SpiDrv::_interruptReq = true;
		srLevel = HIGH;
	}
	else {
		srLevel = LOW;
	}
}

/* -----------------------------------------------------------------
* When the CS signal is active LOW the SPI interface is asserted
*/
void SpiDrv::_enableDevice(void)
{
	digitalWrite(_ss_pin, LOW);
	_ss_status = ss_low;
}

/* -----------------------------------------------------------------
* When the CS signal is active HIGH the SPI interface is released
*/
void SpiDrv::_disableDevice(void)
{
	digitalWrite(_ss_pin, HIGH);
	_ss_status = ss_high;
}

/* -----------------------------------------------------------------
* Initializes the _txBuf buffer with the b byte and sets the buffer index to 1;
*/
void SpiDrv::_txBufInitWByte(uint8_t b)
{
	_txBuf[0] = b;
	_txIndex = 1;
	_pktType = b;
}

/* -----------------------------------------------------------------
* Appends to the _txBuf buffer a new b byte if there's enough space;
*
* return: (boolean)
*		  true byte queued
*		  false otherwise.
*/
bool SpiDrv::_txBufAppendByte(uint8_t b)
{
	if (_txIndex < TXBUF_LEN) {
		_txBuf[_txIndex++] = b;
		return true;
	}
	return false;
}

/* -----------------------------------------------------------------
* Set the overall len of the command packet
*/
void SpiDrv::_txBufSetOverallLen()
{
	if(_pktType == DATA_PKT){ // len is 4 bytes
		_txBuf[2] = _txIndex & 0xFF;
		_txBuf[3] = (_txIndex >> 8) & 0xFF;
		_txBuf[4] = (_txIndex >> 16) & 0xFF;
		_txBuf[5] = (_txIndex >> 24) & 0xFF;
	}
	else // len is 1 byte
		_txBuf[2] = _txIndex;
}


/* -----------------------------------------------------------------
* Finalizes the packet adding the END_CMD and writing out the command
*/
bool SpiDrv::_txBufFinalizePacket()
{
	// add the END_CMD to the buffer
	_txBufAppendByte(END_CMD);
	
	_txBufSetOverallLen();
	
	// write out the data (32 byte minimum) to companion chip
	return _writeData(_txBuf, _txIndex);

}

/*
*
*/
bool SpiDrv::_askStatusInit(uint8_t attempts)
{
	uint32_t timeout;
	while(attempts > 0){
		attempts--;

		_enableDevice();

		intSPI.transfer(START_CMD);
		intSPI.transfer(0x00);
		intSPI.transfer(5);
		intSPI.transfer(0);
		intSPI.transfer(END_CMD);
		intSPI.transfer(0);
		intSPI.transfer(0);
		intSPI.transfer(0); // make sure transmission is 4-bytes multiple length
		_disableDevice();
	
		timeout = millis() + 100;
		while(timeout > millis()) {
			if(srLevel == HIGH){
				handleEvents();
				return true;
			}
		}
	}
	
	return false;
}

/* -----------------------------------------------------------------
* Class constructor
*/
SpiDrv::SpiDrv(void)
{
	_ss_pin = SLAVESELECT;
	_sr_pin = SLAVEREADY;
	
	pinMode(_ss_pin, OUTPUT);
	digitalWrite(_ss_pin, HIGH);
	
	pinMode(SLAVEHANDSHAKE, INPUT);
	
	spiIsr = NULL;
}

/* -----------------------------------------------------------------
* Class begin
*/
void SpiDrv::begin()
{
	_ss_status = ss_high;
	_interruptReq = false;
	_txIndex = 0;

	memset(_txBuf, 0, TXBUF_LEN);

	// this sets the sr pin from companion chip to us and attaches to it a PINCHANGE interrupt.
	pinMode(_sr_pin, INPUT);
	attachInterrupt(digitalPinToInterrupt(_sr_pin), interruptFunction, CHANGE); 
	
	// init master SPI interface
	intSPI.begin();
	// companion SPI Slave frequency must be less than 10 MHz, set maximum speed as possible
	intSPI.setClockDivider(1 + ((F_CPU - 1) / 9500000));
}

/* -----------------------------------------------------------------
* Closes SPI interface
*/
void SpiDrv::end()
{
	intSPI.end();
}

/*
*
*/
bool SpiDrv::establishConnection()
{
	if(_firstLink == false){
		_firstLink = _askStatusInit(10);
	}
	return _firstLink;
}

/* Cmd Struct Message
*  _________________________________________________________________________________ 
* | START CMD | C/R  | CMD  |[TOT LEN]| N.PARAM | PARAM LEN | PARAM  | .. | END CMD |
* |___________|______|______|_________|_________|___________|________|____|_________|
* |   8 bit   | 1bit | 7bit |  8bit   |  8bit   |   8bit    | nbytes | .. |   8bit  |
* |___________|______|______|_________|_________|___________|________|____|_________|
*/
/* Data Struct Message
* __________________________________________________________________________________
*| DATA PKT  | C/R  | CMD  |  OVERALL  |  SOCKET  |  PAYLOAD  | .. |  END DATA PKT |
*|___________|______|______|___ LEN____|__________|___________|____|_______________|
*|   8 bit   | 1bit | 7bit |   32bit   |  8 bit   |   nbytes  | .. |      8bit     |
*|___________|______|______|___________|__________|___________|____|_______________|
*/


/* -----------------------------------------------------------------
* Prepares the _txBuf to be sent as a new command to companion chip
* It requires also the number of attached parameters.
*/
bool SpiDrv::sendCmd(uint8_t cmd, uint8_t numParam)
{
	// init the buffer (32 bytes) with the START_CMD
	_txBufInitWByte(START_CMD);
	// attach the cmd + the complement of the REPLY_FLAG
	_txBufAppendByte(cmd & ~(REPLY_FLAG));
	// put the space for the overall len - 1 byte
	_txBufAppendByte(0);
	// add the number of parameters
	_txBufAppendByte(numParam);
	
	// if no parameters
	if (numParam == 0) {
		return _txBufFinalizePacket();
	}

	return true;
}

/* -----------------------------------------------------------------
* Prepares the _txBuf to be sent as a new data pkt to companion chip
*/
void SpiDrv::sendDataPkt(uint8_t cmd)
{
	// init the buffer (32 bytes) with the START_CMD
	_txBufInitWByte(DATA_PKT);
	// attach the cmd + the complement of the REPLY_FLAG
	_txBufAppendByte(cmd & ~(REPLY_FLAG));
	// put the space for the overall len - 4 byte
	_txBufAppendByte(0);
	_txBufAppendByte(0);
	_txBufAppendByte(0);
	_txBufAppendByte(0);
}

/* -----------------------------------------------------------------
* Add parameters to the command buffer for the companion chip
* It requires also the lastParam parameter to understand which is the last one.
*/
bool SpiDrv::sendParam(uint16_t param, uint8_t lastParam)
{	
	// since each parameter is two bytes wide, add 2 as the parameter size
	_txBufAppendByte(2);
	// then add the parameter (big-endian mode) 
	_txBufAppendByte((uint8_t)((param & 0xff00) >> 8));
	_txBufAppendByte((uint8_t)(param & 0xff));

	// if this is the last parameter
	if (lastParam == 1) {
		return _txBufFinalizePacket();
	}

	return true;
}

/* -----------------------------------------------------------------
* Add a list of parameters to the command buffer for the companion chip (overload)
* It requires the parameter's list (*param), the length of each parameter (param_len)
* and also the lastParam parameter to understand if this is the last one.
*/
bool SpiDrv::sendParam(uint8_t *param, uint8_t param_len, uint8_t lastParam)
{	
	// append parameter size (1 byte)
	_txBufAppendByte(param_len);

	// append all the parameters from the list to the buffer
	for (uint16_t i = 0; i < param_len; ++i) {
		_txBufAppendByte(param[i]);
	}

	// if this is the last parameter
	if (lastParam == 1) {
		return _txBufFinalizePacket();
	}

	return true;
}

/* -----------------------------------------------------------------
* Add byte to the command buffer for the companion chip
* It requires also the lastParam parameter to understand which is the last one.
*/
bool SpiDrv::appendByte(uint8_t data, uint8_t lastParam){
	_txBufAppendByte(data);
	
	// if this is the last parameter
	if (lastParam == 1) {
		return _txBufFinalizePacket();
	}

	return true;
}

/* -----------------------------------------------------------------
* Add a buffer to the command for the companion chip and send the so created packet
*/
bool SpiDrv::appendBuffer(const uint8_t *data, uint32_t len){
	// calculate and send the overall length
	uint32_t totalLen = _txIndex + len + 1; // 1 byte more to store end command byte
	if(_pktType == DATA_PKT){ // len is 4 bytes
		_txBuf[2] = totalLen & 0xFF;
		_txBuf[3] = (totalLen >> 8) & 0xFF;
		_txBuf[4] = (totalLen >> 16) & 0xFF;
		_txBuf[5] = (totalLen >> 24) & 0xFF;
	}
	else // len is 1 byte
		_txBuf[2] = totalLen;
		
	// copy memory address
	memcpy(&_txBuf[_txIndex], &data, 4);

	return _writeBuffPkt(_txBuf, totalLen, _txIndex);
}
/* -----------------------------------------------------------------
* Writes to the companion a pre-allocated buffer (mainly used for _txBuf)
*
* params: uint8_t* data:	the buffer pointer
*		  uint16_t len:		number of parameters to read
*/
bool SpiDrv::_writeData(uint8_t *data, uint32_t len)
 {
	uint8_t readBuf[SPI_MAX_TX_SIZE] = {0};
	uint32_t byteWritten = 0;
	bool ret = false;
	
	// send all the packets
	while (len > 0) {
		while(digitalRead(SLAVEHANDSHAKE) != HIGH); // wait for handshake - when HIGH companion is ready for a new transaction
			_enableDevice();

			// make sure to send a SPI_MAX_TX_SIZE multiple as to avoid loosing data on the other micro
			if(len > SPI_MAX_TX_SIZE){
				intSPI.transfer((void*)&data[byteWritten], SPI_MAX_TX_SIZE, (void*)readBuf);
				byteWritten += SPI_MAX_TX_SIZE;
				len -= SPI_MAX_TX_SIZE;
			}
			else{ // write the last chunk
				intSPI.transfer((void*)&data[byteWritten], len, (void*)readBuf);
				uint8_t i = 0;
				// add a 0 padding for the remaining bytes as to send always a 4-byte multiple length per transmission
				for(uint8_t remaining = len % 4; remaining > 0 && remaining < 4; remaining++, i++){
					readBuf[len + i] = intSPI.transfer(0);
				}
				byteWritten += len;
				len -= len;
			}
		
			_disableDevice();
			
			// check ack
			uint32_t timeout = millis() + 10000;
			// wait for the SR to go HIGH
			while(srLevel != HIGH && timeout > millis());
			if(timeout <= millis()){
				return false;
			}
			
			// if the SR is HIGH before the end of the timeout..
			if(srLevel == HIGH){
				// wait to make sure this is not an ack
				delayMicroseconds(15);
			}
			
			ret = true;

			if(readBuf[1] != 0){
				if(spiIsr != NULL)
					spiIsr(readBuf);
			}
		}
	return ret;
}

/*
*
*/
bool SpiDrv::_writeBuffPkt(uint8_t *data, uint32_t len, uint8_t dataOffset)
{
	uint8_t readBuf[SPI_MAX_TX_SIZE] = {0};
	uint8_t* buffPtr = &readBuf[0];
	
	bool ret = true;
	uint16_t j = 0;
	bool firstWrite = true;
	

	uint32_t addrMem = (uint32_t)(data[dataOffset] + (data[dataOffset + 1] << 8) + (data[dataOffset + 2] << 16) + (data[dataOffset + 3] << 24));
	
		// write out the data
	while (len > 0){
		while(digitalRead(SLAVEHANDSHAKE) != HIGH); // wait for handshake - when HIGH companion is ready for a new transaction
			_enableDevice();
			
			if(firstWrite){
				// send header
				intSPI.transfer((void*)data, dataOffset, (void*)buffPtr);
				buffPtr+=dataOffset; // do not override just read data if any
			}
			if(len > SPI_MAX_TX_SIZE){
				// data are greater than SPI_MAX_TX_SIZE. Multiple writes are requested
				intSPI.transfer((void*)(addrMem + j), SPI_MAX_TX_SIZE - dataOffset, (void*)buffPtr);
				j += SPI_MAX_TX_SIZE - dataOffset;
				len -= SPI_MAX_TX_SIZE; // consider also dataOffset that we previously transferred
				if(firstWrite){
					firstWrite = false;
					buffPtr-=dataOffset; // move pointer back to its original value
				}
			}
			else{
				// data fit SPI_MAX_TX_SIZE
				intSPI.transfer((void*)(addrMem + j), len - dataOffset - 1, (void*)buffPtr);
				// send END_CMD
				readBuf[len - 1] = intSPI.transfer(END_CMD);
				uint8_t i = 0;
				// add a 0 padding for the remaining bytes as to send always a 4-byte multiple length per transmission
				for(uint8_t remaining = len % 4; remaining > 0 && remaining < 4; remaining++, i++){
					readBuf[len + i] = intSPI.transfer(0);
				}
				if(firstWrite){
					firstWrite = false;
					buffPtr-=dataOffset; // move pointer back to its original value
				}
			
				len -= len;
			}
			dataOffset = 0;

			_disableDevice();
			
			
			// check ack
			uint32_t timeout = millis() + 2000;
			// wait for the SR to go HIGH
			while(srLevel != HIGH && timeout > millis());
			
			if(timeout <= millis()){
				return false;
			}
			
			// if the SR is HIGH before the end of the timeout..
			if(srLevel == HIGH){
				// wait for the ack pulse to go back low
				delayMicroseconds(15);
				// if it doesn't go low -> we could have an async event.
				if(srLevel == HIGH){
					_interruptReq = true;
					// read the event and check if SR goes low (inside the read function)
					handleEvents();
					
					if(_ss_status == HIGH)
						digitalWrite(_ss_pin, LOW);
					
					// after the read the SR is still HIGH, we have and error
					if(srLevel == HIGH){
						ret = false;
					}
				}
				_interruptReq = false;
			}
			
			if(readBuf[1] != 0){
				if(spiIsr != NULL)
					spiIsr(readBuf);
			}			
		}	
	return ret;
}

/* -----------------------------------------------------------------
* Read data from the companion chip after an ISR event (32 bytes per time)
* params: uint8_t* buffer:	data buffer to store the received data
* 
* return: (uint16_t)
*		   byte read.
*/
uint16_t SpiDrv::readDataISR(uint8_t *buffer)
{
	uint16_t byteRead = BUF_SIZE;
	uint8_t emptyBuf[BUF_SIZE] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	
	delayMicroseconds(12); // useful to make sure this is not an ack
	// wait for the SRsr signal HIGH - companion is ready
	if(digitalRead(_sr_pin) == HIGH){
		while(digitalRead(SLAVEHANDSHAKE) != HIGH); // wait for handshake - when HIGH companion is ready for a new transaction
		_enableDevice();

		// read all the 32 bytes available in the companion data out buffer
		intSPI.transfer((void*)emptyBuf, BUF_SIZE, (void*)buffer);

		_disableDevice();
	} 
	else {
		// if the SR is still low, return with an error	
		return 0;
	}
			
	// after reading all the 32 byte long message we need to ensure that the SR goes low again
	uint32_t t_hold = millis() + 10;
	while(t_hold > millis()){

		// if we are in a multipacket case...
		if(srLevel == LOW){
			if(buffer[0] == 0){
				// probably this read needed to empty the companion's spi buffer. Return 0 in order to avoid decoding of a 0 packet
				return 0;
			}
			return byteRead;
		}
	}
		
	return 0;
}

/* -----------------------------------------------------------------
* The function watches the _interruptReq variable set in the interruptFunction
* when companion fires an ISR. If the callback exists it will be called
*/
void SpiDrv::handleEvents(void)
{
	if(spiIsr && _interruptReq){
		_interruptReq = false;
		spiIsr(NULL);
	}
}

/* -----------------------------------------------------------------
* Registers the callback
*/
void SpiDrv::registerCb(tpDriverIsr pfIsr)
{
	spiIsr = pfIsr;
}

#endif