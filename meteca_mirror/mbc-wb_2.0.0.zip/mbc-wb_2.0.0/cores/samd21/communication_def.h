/*
  Meteca SA.  All right reserved.
  created by Dario Trimarchi and Chiara Ruggeri 2017-2018
  email: support@meteca.org

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef COMM_DEF_H
#define COMM_DEF_H

#include "communication_channel.h"

#if defined(ESP_CH_UART)
  #include "uart/uart_def.h"
#elif defined(ESP_CH_SPI)
  #include "spi/spi_def.h"
#endif

#include <inttypes.h>

#define CMD_FLAG        0
#define REPLY_FLAG      1<<7
#define DATA_FLAG 		0x40

enum {
	// Generic
	NONE				= 0x00,
	GPIO_REQUEST		= 0x01,
	GPIO_RESPONSE		= 0x02,
	PUT_CUSTOM_DATA		= 0x03,
	TEST_CMD	        = 0x04,
   	GET_TEST_CMD		= 0x05
};


enum numParams{
    PARAM_NUMS_0,
    PARAM_NUMS_1,
    PARAM_NUMS_2,
    PARAM_NUMS_3,
    PARAM_NUMS_4,
    PARAM_NUMS_5,
    MAX_PARAM_NUMS
};

#define MAX_PARAMS MAX_PARAM_NUMS-1
#define PARAM_LEN_SIZE 1

#endif // COMM_DEF_H