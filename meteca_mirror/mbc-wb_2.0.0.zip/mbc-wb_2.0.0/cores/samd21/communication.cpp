/*
  Meteca SA.  All right reserved.
  created by Dario Trimarchi and Chiara Ruggeri 2017-2018
  email: support@meteca.org

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "communication.h"
#include "Arduino.h"

void communicationEvtCb(uint8_t* pkt){
    if (pkt != NULL) { // data was received during a write. copy data into commonDrv buffer before to decode them
        memcpy(communication._rxBuf, pkt, BUF_SIZE);
    } else {
        // read the data out from the communication interface and put them into a buffer
		uint8_t temp[BUF_SIZE];
        uint8_t ret = communication._interface.readDataISR(temp);
		
        // decode the BUF_SIZE bytes long packet
        if (ret == 0){
            return;
		}
			
		memcpy(communication._rxBuf, temp, BUF_SIZE);
    }
	uint8_t cmd = communication._rxBuf[1] - 0x80;
		
	if(communication._endReceived == false)
		cmd = communication._currentCmd; // retrieve the command we are processing
	
	// check if command belongs to the user-specified ones
	if(cmd == CUSTOM_CMD_CODE){
		if(communication._cmdIndex){
			uint8_t customCmd;
			if(communication._endReceived == false)
				customCmd = communication._customCurrentCmd;
			else
				customCmd = communication._rxBuf[6];
			for(uint8_t i = 0; i < communication._cmdIndex; i++){
				if(customCmd == communication._customCmdCode[i]){
					if(communication._endReceived){ // new command
						communication._totPktLen = (uint32_t)(communication._rxBuf[2] + (communication._rxBuf[3] << 8) + (communication._rxBuf[4] << 16) + (communication._rxBuf[5] << 24));
						uint8_t copyLen;
						if(communication._totPktLen <= BUF_SIZE){ // data are contained in a single packet
							copyLen = communication._totPktLen - 8;
							communication._endReceived = true;
							// control the packet footer.
							if(communication._rxBuf[communication._totPktLen - 1] != END_CMD){
								return; // error
							}
							
							// copy data
							if(communication._custom_ext_buff[i] != NULL)
								memcpy(&communication._custom_ext_buff[i][0], &communication._rxBuf[7], copyLen);
							communication._custom_buff_index = copyLen;
							
							// call user defined callback
							if(communication._userCallbacks[i] != NULL)
								communication._userCallbacks[i](communication._custom_buff_index);
							
							communication._custom_buff_index = 0;
							return;
							
						}
						else{
							copyLen = BUF_SIZE - 7; // buffer size - header
							communication._endReceived = false;
							communication._currentCmd = cmd;
							communication._customCurrentCmd = customCmd;
	
							// copy the first chunk
							if(communication._custom_ext_buff[i] != NULL)
								memcpy(&communication._custom_ext_buff[i][0], &communication._rxBuf[7], copyLen);
							communication._custom_buff_index = copyLen;			
							return;
						}
					}
					else{ // command continuation
						if((communication._custom_buff_index + BUF_SIZE) >= (communication._totPktLen - 8)){ // last chunk
							uint8_t copyLen = BUF_SIZE - ((communication._custom_buff_index + BUF_SIZE) - (communication._totPktLen - 8));
							if(communication._custom_ext_buff[i] != NULL)
								memcpy(&communication._custom_ext_buff[i][communication._custom_buff_index], communication._rxBuf, copyLen);
							communication._endReceived = true;
							communication._custom_buff_index += copyLen;
							
							communication._totPktLen = 0;
							// call user defined callback
							if(communication._userCallbacks[i] != NULL)
								communication._userCallbacks[i](communication._custom_buff_index);
							communication._custom_buff_index = 0;
							communication._currentCmd = 0;
							return;
						}
						else{ // intermediate chunk
							if(communication._custom_ext_buff[i] != NULL)
								memcpy(&communication._custom_ext_buff[i][communication._custom_buff_index], communication._rxBuf, BUF_SIZE);
							communication._custom_buff_index += BUF_SIZE;
							return;
						}
					}
					break;
				}
			}
		}
		return;
	}

	// check all other commands
	switch(cmd){
		case GPIO_RESPONSE:
			communication._responseType = GPIO_RESPONSE;
		break;
		
		case GPIO_REQUEST:
			communication._moveGpio();
		break;
		
		// process PUT_CUSTOM_DATA command sent from the other micro
		case PUT_CUSTOM_DATA:
			if(communication._endReceived){ // new command
				communication._totPktLen = (uint32_t)(communication._rxBuf[2] + (communication._rxBuf[3] << 8) + (communication._rxBuf[4] << 16) + (communication._rxBuf[5] << 24));
				if(communication._user_ext_buff == NULL){ // create a safe place where storing data
					// note: what follows is not a safe instruction for a microcontroller and should be avoided by using initExternalBuffer function.
					communication._user_ext_buff = (uint8_t*)malloc(communication._totPktLen);
				}
				uint8_t copyLen;
				if(communication._totPktLen <= 32){ // data are contained in a single packet
					copyLen = communication._totPktLen - 7;
					communication._endReceived = true;
					// control the packet footer.
					if(communication._rxBuf[communication._totPktLen - 1] != END_CMD){
						return; // error
					}
					
					// copy data
					if(communication._user_ext_buff != NULL)
						memcpy(communication._user_ext_buff, &communication._rxBuf[6], copyLen);
					communication._user_ext_buff_sz = copyLen;
					
					return;
					
				}
				else{
					copyLen = BUF_SIZE - 6; // buffer size - header
					communication._endReceived = false;
					communication._currentCmd = cmd;

					// copy the first chunk
					if(communication._user_ext_buff != NULL)
						memcpy(communication._user_ext_buff, &communication._rxBuf[6], copyLen);
					communication._user_ext_buff_sz = copyLen;			
					return;
				}
			}
			else{ // command continuation
				if((communication._user_ext_buff_sz + BUF_SIZE) >= (communication._totPktLen - 7)){ // last chunk
					uint8_t copyLen = BUF_SIZE - ((communication._user_ext_buff_sz + BUF_SIZE) - (communication._totPktLen - 7));
					if(communication._user_ext_buff != NULL)
						memcpy(&communication._user_ext_buff[communication._user_ext_buff_sz], communication._rxBuf, copyLen);
					communication._endReceived = true;
					communication._user_ext_buff_sz += copyLen;
					
					communication._totPktLen = 0;
					
					communication._currentCmd = 0;
					return;
				}
				else{ // intermediate chunk
					if(communication._user_ext_buff != NULL)
						memcpy(&communication._user_ext_buff[communication._user_ext_buff_sz], communication._rxBuf, BUF_SIZE);
					communication._user_ext_buff_sz += BUF_SIZE;
					return;
				}
			}
		break;

		default:
			// call user defined handlers
			communication._responseType = NONE;
			for(uint8_t i = 0; i < EXT_HANDLES; i++)
				if(communication._handleExt[i] != NULL)
					communication._handleExt[i](communication._rxBuf);
				
		break;
	}
}

void Communication::communicationBegin(){
	_interface.begin();
	_interface.registerCb(communicationEvtCb);
}


bool Communication::registerCommand(uint8_t cmdCode, ext_callback function, uint8_t* buffer){
	handleCommEvents();
	
	if(_cmdIndex == CUSTOM_CMD_NR)
		return false; // do not accept more than CUSTOM_CMD_NR commands

	for(uint8_t i = 0; i < _cmdIndex; i++){
		if(_customCmdCode[i] == cmdCode)
			return false; // do not accept an already assigned command code
	}
		
	if(buffer != NULL)
		_custom_ext_buff[_cmdIndex] = buffer;
	
	_customCmdCode[_cmdIndex] = cmdCode;
	_userCallbacks[_cmdIndex] = function;
	_cmdIndex++;
	return true;
}

void Communication::sendCommand(uint8_t cmdCode, uint8_t* data, uint32_t len){
	handleCommEvents();
	bool existing = false;
	
	// check if cmdCode is an already registered one
	for(uint8_t i = 0; i < _cmdIndex; i++){
		if(_customCmdCode[i] == cmdCode){
			existing = true;
			break;
		}
	}
	if(!existing) // do not send a command that has not been previously registered
		return;

	communication.sendDataPkt(CUSTOM_CMD_CODE);
	communication.appendByte(cmdCode);
	communication.appendBuffer(data, len);
}

void Communication::initExternalBuffer(uint8_t* extBuf){
    _user_ext_buff = extBuf;
}

int32_t Communication::availGenericData(void){
    handleCommEvents();

    // check if there are new data for our socket
    if (_endReceived && _user_ext_buff_sz > 0) {
        return _user_ext_buff_sz;
    }
    return 0;
}

uint32_t Communication::getGenericData(uint8_t *data, uint32_t len){
	uint32_t size = _user_ext_buff_sz;
	if(data != NULL){
		// get minimum between len and _user_ext_buff_sz
		if(len > 0)
			size = (len > _user_ext_buff_sz) ? _user_ext_buff_sz : len;
		memcpy(data, _user_ext_buff, size);
	}
	_user_ext_buff_sz = 0;
	return size;
}

void Communication::sendGenericData(const char* data, uint32_t len){
    handleCommEvents();
    
	communication.sendDataPkt(PUT_CUSTOM_DATA);
	communication.appendBuffer((uint8_t*)data, len);
}


bool Communication::registerHandle(void(*func)(uint8_t*)){
	bool registered = false;
	for(uint8_t i = 0; i < EXT_HANDLES; i++){
		// look for the first available space for the handle
		if(_handleExt[i] == NULL){
			_handleExt[i] = func;
			registered = true;
			break;
		}
	}
	return registered;
}

void Communication::handleCommEvents(void){
	_interface.handleEvents();
}

/*
* Process GPIO_REQUEST command by actuating the selected operation on the specified pin
*/
void Communication::_moveGpio(){
	bool rep = false;
	uint8_t* dataBuf = &_rxBuf[5]; // skip packet header
	uint8_t op = dataBuf[0];
	uint8_t pin = dataBuf[2];
	uint8_t mode;
	uint32_t val = 0;
	uint32_t result = 0;
		
	switch(op){
		case PIN_MODE: // pinMode command
			mode = dataBuf[4]; 
			pinMode(pin, mode);
			rep = false; // no reply needed
		break;
		case WRITE_DIGITAL: // digitalWrite command
			val = dataBuf[4] + (dataBuf[5] << 8) + (dataBuf[6] << 16) + (dataBuf[7] << 24);
			digitalWrite(pin, val);
			rep = false;
		break;
		case WRITE_ANALOG: // analogWrite command
			val = dataBuf[4] + (dataBuf[5] << 8) + (dataBuf[6] << 16) + (dataBuf[7] << 24);
			analogWrite(pin, val);
			
			rep = false;
		break;
		case READ_DIGITAL: // digitalRead command	
			result = digitalRead(pin);
			rep = true;
		break;
		case READ_ANALOG: // analogRead command
			result = analogRead(pin);
			rep = true;
		break;
		default:
			rep = false;
		break;
	}
	
	if(rep == true){
		//send reply
		_interface.sendCmd(GPIO_RESPONSE, PARAM_NUMS_1);
		_interface.sendParam((uint8_t*)&result, 4, LAST_PARAM);
	}
	return;
}

void Communication::clearResponseType(){
	_responseType = NONE;
}

uint8_t Communication::getResponseType(){
	return _responseType;
}


bool Communication::sendCmdPkt(uint8_t cmd, uint8_t numParam){
	return _interface.sendCmd(cmd, numParam);
}

void Communication::sendDataPkt(uint8_t cmd){
	_interface.sendDataPkt(cmd);
}

bool Communication::sendParam(uint8_t *param, uint8_t param_len, uint8_t lastParam){
	return _interface.sendParam(param, param_len, lastParam);
}

bool Communication::sendParam(uint16_t param, uint8_t lastParam){
	return _interface.sendParam(param, lastParam);
}

bool Communication::appendByte(uint8_t data, uint8_t lastParam){
	return _interface.appendByte(data, lastParam);
}

bool Communication::appendBuffer(const uint8_t *data, uint32_t len){
	return _interface.appendBuffer(data, len);
}

uint8_t* Communication::getRxBuffer(){
	return _rxBuf;
}

Communication communication;

/*
* Activate pinMode function on one of the pin connected to the companion chip
*
* param op: a code representing the operation to be performed
* param pin: pin on which operation has to take effect
* param mod: mode applied to pin (e.g. OUTPUT, INPUT and so on)
*/
extern "C" void sendGPIOMode(uint8_t op, uint8_t pin, uint8_t mod){
	communication.handleCommEvents();
	
	communication.sendCmdPkt(GPIO_REQUEST, PARAM_NUMS_3);
	communication.sendParam(&op, 1, NO_LAST_PARAM);
	communication.sendParam(&pin, 1, NO_LAST_PARAM);
	communication.sendParam(&mod, 1, LAST_PARAM);
}

/*
* Activate digitalWrite or analogWrite function on one of the pin connected to the companion chip
*
* param op: a code representing the operation to be performed (WRITE_DIGITAL or WRITE_ANALOG)
* param pin: pin on which operation has to take effect
* param mod: value to be applied to pin
*/
extern "C" void sendGPIOWrite(uint8_t op, uint8_t pin, uint32_t val){
	communication.handleCommEvents();
	
	communication.sendCmdPkt(GPIO_REQUEST, PARAM_NUMS_1);
	communication.sendParam(&op, 1, NO_LAST_PARAM);
	communication.sendParam(&pin, 1, NO_LAST_PARAM);
	communication.sendParam((uint8_t*)&val, 4, LAST_PARAM);
}

/*
* Activate digitalRead or analogRead function on one of the pin connected to the companion chip
*
* param op: a code representing the operation to be performed (READ_DIGITAL or READ_ANALOG)
* param pin: pin on which operation has to take effect
*
* return: the read value
*/
extern "C" int32_t sendGPIORead(uint8_t op, uint8_t pin){
	communication.handleCommEvents();
	
	communication.clearResponseType();
	communication.sendCmdPkt(GPIO_REQUEST, PARAM_NUMS_2);
	communication.sendParam(&op, 1, NO_LAST_PARAM);
	communication.sendParam(&pin, 1, LAST_PARAM);

    // Poll response for the next 2 seconds
    uint32_t start = millis();
    while (((millis() - start) < 2000)) {
        communication.handleCommEvents();
        if (communication.getResponseType() == GPIO_RESPONSE) {
			uint8_t* dataBuf = communication.getRxBuffer();
			dataBuf += 5; // skip packet header
            uint32_t result = dataBuf[0] + (dataBuf[1] << 8) + (dataBuf[2] << 16) + (dataBuf[3] << 24);
			return result;
        }
    }
    return -1;
}