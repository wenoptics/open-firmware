/*
  Meteca SA.  All right reserved.
  created by Dario Trimarchi and Chiara Ruggeri 2017-2018
  email: support@meteca.org

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "communication_channel.h"

#if defined(ESP_CH_UART)

#ifndef UART_Drv_h
#define UART_Drv_h

#include "WString.h"
#include <inttypes.h>

#define NO_LAST_PARAM       0
#define LAST_PARAM          1
#define DUMMY_DATA          0x00
#define TXBUF_LEN           BUF_SIZE << 1

#define UART_BAUDRATE       1500000

#define ESP_SR_TIMEOUT      1000

#define SLAVESELECT      ESP_CS
#define SLAVEREADY       ACK_PIN

typedef void (*tpDriverIsr)(uint8_t*);

class UartDrv {
  private:
	
	uint8_t _txIndex;
	uint8_t _txBuf[TXBUF_LEN];
	static volatile uint8_t _interruptReq;
	uint8_t _pktType = START_CMD;
	
	void _ack();
	void _txBufInitWByte(uint8_t b);
	bool _txBufAppendByte(uint8_t b);
	bool _txBufFinalizePacket();
	void _txBufSetOverallLen();
	
	bool _writeData(uint8_t *data, uint32_t len);
	bool _writeBuffPkt(uint8_t *data, uint32_t len, uint8_t offset);
	
	friend void interruptFunction();
	
  public:
	// generic functions
	UartDrv();
	void begin();
	void end();
	bool establishConnection();
	
	// callback functions
	void handleEvents(void);
	void registerCb(tpDriverIsr pfIsr);
	void srCbHandler(void);
	
	// command related functions
	bool sendCmd(uint8_t cmd, uint8_t numParam);
	void sendDataPkt(uint8_t cmd);
	bool sendParam(uint8_t *param, uint8_t param_len, uint8_t lastParam = NO_LAST_PARAM);
	bool sendParam(uint16_t param, uint8_t lastParam = NO_LAST_PARAM);
	bool appendByte(uint8_t data, uint8_t lastParam = NO_LAST_PARAM);
	bool appendBuffer(const uint8_t *data, uint32_t len);
	
	// SPI Data Register functions
	uint16_t readDataISR(uint8_t *buffer);
	
};

#endif
#endif