/*
  Meteca SA.  All right reserved.
  created by Dario Trimarchi and Chiara Ruggeri 2017-2018
  email: support@meteca.org

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "communication_channel.h"

#if defined(ESP_CH_UART)

#include "Arduino.h"

static tpDriverIsr uartIsr;

volatile uint8_t UartDrv::_interruptReq = 0;

void interruptFunction(){
	UartDrv::_interruptReq++;
	digitalWrite(SLAVESELECT, LOW);
}

/* -----------------------------------------------------------------
* Class constructor
*/
UartDrv::UartDrv(void){
	uartIsr = NULL;
}

void UartDrv::begin(){
	SerialEsp.end();
	SerialEsp.begin(UART_BAUDRATE);
	
	// this sets the sr pin from companion chip to us and attaches to it a RISING interrupt.
	pinMode(SLAVEREADY, INPUT);
	attachInterrupt(digitalPinToInterrupt(SLAVEREADY), interruptFunction, RISING);
	pinMode(SLAVESELECT, OUTPUT);
	digitalWrite(SLAVESELECT, HIGH);
}

void UartDrv::end(){
	SerialEsp.end();
}

bool UartDrv::establishConnection(){
	
}


/* -----------------------------------------------------------------
* The function watches the _interruptReq variable set in the _SRcallback
* when companion fires an ISR. If the callback exists it will be called
*/
void UartDrv::handleEvents(){
	if(uartIsr && _interruptReq){
		_interruptReq--;
		uartIsr(NULL);
	}	
}

void UartDrv::registerCb(tpDriverIsr pfIsr){
	uartIsr = pfIsr;	
}

void UartDrv::srCbHandler(void){
}


/* -----------------------------------------------------------------
* Prepares the _txBuf to be sent as a new command to companion chip
* It requires also the number of attached parameters.
*/
bool UartDrv::sendCmd(uint8_t cmd, uint8_t numParam){
	// init the buffer with the START_CMD
	_txBufInitWByte(START_CMD);
	// attach the cmd + the complement of the REPLY_FLAG
	_txBufAppendByte(cmd & ~(REPLY_FLAG));
	// put the space for the overall len - 1 byte
	_txBufAppendByte(0);
	// add the number of parameters
	_txBufAppendByte(numParam);
	
	// if no parameters
	if (numParam == 0) {
		return _txBufFinalizePacket();
	}

	return true;
}

/* -----------------------------------------------------------------
* Prepares the _txBuf to be sent as a new data pkt to companion chip
*/
void UartDrv::sendDataPkt(uint8_t cmd){
	// init the buffer with the START_CMD
	_txBufInitWByte(DATA_PKT);
	// attach the cmd + the complement of the REPLY_FLAG
	_txBufAppendByte(cmd & ~(REPLY_FLAG));
	// put the space for the overall len - 4 byte
	_txBufAppendByte(0);
	_txBufAppendByte(0);
	_txBufAppendByte(0);
	_txBufAppendByte(0);
}

/* -----------------------------------------------------------------
* Add a list of parameters to the command buffer for the companion chip (overload)
* It requires the parameter's list (*param), the length of each parameter (param_len)
* and also the lastParam parameter to understand if this is the last one.
*/
bool UartDrv::sendParam(uint8_t *param, uint8_t param_len, uint8_t lastParam){
	// append parameter size (1 byte)
	_txBufAppendByte(param_len);

	// append all the parameters from the list to the buffer
	for (uint16_t i = 0; i < param_len; ++i) {
		_txBufAppendByte(param[i]);
	}

	// if this is the last parameter
	if (lastParam == 1) {
		return _txBufFinalizePacket();
	}

	return true;
}

/* -----------------------------------------------------------------
* Add parameters to the command buffer for the companion chip
* It requires also the lastParam parameter to understand which is the last one.
*/
bool UartDrv::sendParam(uint16_t param, uint8_t lastParam){
	// since each parameter is two bytes wide, add 2 as the parameter size
	_txBufAppendByte(2);
	// then add the parameter (big-endian mode) 
	_txBufAppendByte((uint8_t)((param & 0xff00) >> 8));
	_txBufAppendByte((uint8_t)(param & 0xff));

	// if this is the last parameter
	if (lastParam == 1) {
		return _txBufFinalizePacket();
	}

	return true;	
}

/* -----------------------------------------------------------------
* Add byte to the command buffer for the companion chip
* It requires also the lastParam parameter to understand which is the last one.
*/
bool UartDrv::appendByte(uint8_t data, uint8_t lastParam){
	_txBufAppendByte(data);
	
	// if this is the last parameter
	if (lastParam == 1) {
		return _txBufFinalizePacket();
	}

	return true;
}

/* -----------------------------------------------------------------
* Add a buffer to the command for the companion chip and send the so created packet
*/
bool UartDrv::appendBuffer(const uint8_t *data, uint32_t len){
	// calculate and send the overall length
	uint32_t totalLen = _txIndex + len + 1; // 1 byte more to store end command byte
	if(_pktType == DATA_PKT){ // len is 4 bytes
		_txBuf[2] = totalLen & 0xFF;
		_txBuf[3] = (totalLen >> 8) & 0xFF;
		_txBuf[4] = (totalLen >> 16) & 0xFF;
		_txBuf[5] = (totalLen >> 24) & 0xFF;
	}
	else // len is 1 byte
		_txBuf[2] = totalLen;
		
	// copy memory address
	memcpy(&_txBuf[_txIndex], &data, 4);

	return _writeBuffPkt(_txBuf, totalLen, _txIndex);
}

/* -----------------------------------------------------------------
* Read data from the companion chip after an ISR event
* params: uint8_t* buffer:	data buffer to store the received data
* 
* return: (uint16_t)
*		   byte read.
*/
uint16_t UartDrv::readDataISR(uint8_t *buffer){
	uint16_t available = SerialEsp.available();
	for(uint16_t i = 0; i < available; i++)
		buffer[i] = SerialEsp.read();

	_ack();
	return available;
}


/* -----------------------------------------------------------------
* Move SS pin HIGH to signal that a packet has been read and we are ready
* to receive a new one.
*/
void UartDrv::_ack(){
	digitalWrite(SLAVESELECT, HIGH);
}

/* -----------------------------------------------------------------
* Finalizes the packet adding the END_CMD and writing out the command
*/
bool UartDrv::_txBufFinalizePacket(){
	// add the END_CMD to the buffer
	_txBufAppendByte(END_CMD);
	
	_txBufSetOverallLen();
	
	// write out the data (32 byte minimum) to companion chip
	return _writeData(_txBuf, _txIndex);

}

/* -----------------------------------------------------------------
* Appends to the _txBuf buffer a new b byte if there's enough space;
*
* return: (boolean)
*		  true byte queued
*		  false otherwise.
*/
bool UartDrv::_txBufAppendByte(uint8_t b){
	if (_txIndex < TXBUF_LEN) {
		_txBuf[_txIndex++] = b;
		return true;
	}
	return false;
}

/* -----------------------------------------------------------------
* Set the overall len of the command packet
*/
void UartDrv::_txBufSetOverallLen(){
	if(_pktType == DATA_PKT){ // len is 4 bytes
		_txBuf[2] = _txIndex & 0xFF;
		_txBuf[3] = (_txIndex >> 8) & 0xFF;
		_txBuf[4] = (_txIndex >> 16) & 0xFF;
		_txBuf[5] = (_txIndex >> 24) & 0xFF;
	}
	else // len is 1 byte
		_txBuf[2] = _txIndex;
}

/* -----------------------------------------------------------------
* Initializes the _txBuf buffer with the b byte and sets the buffer index to 1;
*/
void UartDrv::_txBufInitWByte(uint8_t b){
	_txBuf[0] = b;
	_txIndex = 1;
	_pktType = b;
}


/* -----------------------------------------------------------------
* Writes to the companion a pre-allocated buffer (mainly used for _txBuf)
*
* params: uint8_t* data:	the buffer pointer
*		  uint16_t len:		number of parameters to read
*/
bool UartDrv::_writeData(uint8_t *data, uint32_t len){
	uint32_t byteWritten = 0;
	
	// send all the packets
	while (len > 0) {
		// make sure to send a UART_MAX_TX_SIZE multiple as to avoid loosing data on the other micro
		if(len > UART_MAX_TX_SIZE){
			SerialEsp.write(&data[byteWritten], UART_MAX_TX_SIZE);
			byteWritten += UART_MAX_TX_SIZE;
			len -= UART_MAX_TX_SIZE;
		}
		else{ // write the last chunk
			SerialEsp.write(&data[byteWritten], len);
			byteWritten += len;
			len -= len;
		}
	}
		
	// check ack
	uint32_t timeout = millis() + 10000;
	// wait for the SR to go HIGH
	while(_interruptReq == 0 && timeout > millis());
	if(timeout <= millis()){
		return false;
	}
	
	return true;
}

bool UartDrv::_writeBuffPkt(uint8_t *data, uint32_t len, uint8_t dataOffset){	
	bool ret = true;
	uint16_t j = 0;
	bool firstWrite = true;

	uint32_t addrMem = (uint32_t)(data[dataOffset] + (data[dataOffset + 1] << 8) + (data[dataOffset + 2] << 16) + (data[dataOffset + 3] << 24));

	// write out the data
	while (len > 0){
		if(firstWrite){
			// send header
			SerialEsp.write(data, dataOffset);
			firstWrite = false;
		}
		if(len > UART_MAX_TX_SIZE){
			// data are greater than UART_MAX_TX_SIZE. Multiple writes are requested
			SerialEsp.write((uint8_t*)(addrMem + j), UART_MAX_TX_SIZE - dataOffset);
			j += UART_MAX_TX_SIZE - dataOffset;
			len -= UART_MAX_TX_SIZE; // consider also dataOffset that we previously transferred
		}
		else{
			// data fit UART_MAX_TX_SIZE
			SerialEsp.write((uint8_t*)(addrMem + j), len - dataOffset - 1);
			// send END_CMD
			SerialEsp.write(END_CMD);
		
			len -= len;
		}
		dataOffset = 0;		

		// check ack
		uint32_t timeout = millis() + 2000;
		// wait until SR to go HIGH and a new ISR is requested
		while(_interruptReq == 0 && timeout > millis());

		if(timeout <= millis()){
			return false;
		}
	}
	return ret;
}

#endif