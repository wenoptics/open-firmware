#ifndef MQTT_H
#define MQTT_H

#if defined BRIKI_MBC_WB_SAMD
#error "Sorry, MQTT library doesn't work with samd21 processor"
#endif

#include "MQTTClient.h"

#endif
